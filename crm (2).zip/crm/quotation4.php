<?php
require('report/mc_table.php');
//require_once("../businessLogic/Database.php");
//require_once("../businessLogic/Project.php");
//require_once("../businessLogic/Customers.php");
//require_once("../businessLogic/Followup.php");
//require_once("../businessLogic/AdminUser.php");
//require_once("../businessLogic/Lead.php");
//require_once("../businessLogic/Common.php");
//require_once("../businessLogic/LeadFollowup.php");
//require_once("../businessLogic/Activity.php");
//require_once("../businessLogic/Leadproduct.php");
//require_once("../businessLogic/Product.php");
//require_once("../businessLogic/Notification.php");
//require_once("../businessLogic/Quotation.php");
//require_once("../businessLogic/QuotationDetails.php");
//require_once("../businessLogic/Account.php");

//$project = new Project();
//if($project->getMaintainenceFlag()=="true")
//{
 // header("location: maintenance");
  //exit;
//}

//$project = new Project();
//$page='quotation';

//$database = new Database();
//$db = $database->getConnection();
//$customer = new Customers($db);
//$customergroup = new CustomerGroup($db);
//$followup = new FollowUp($db);
//$adminuser = new AdminUser($db);
//$user = new AdminUser($db);
//$lead = new Lead($db);
//$followup = new FollowUp($db);
//$common = new Common($db);
//$leadfollowup = new Leadfollowup($db);
//$activity = new Activity($db);
//$leadproduct = new Leadproduct($db);
//$product = new Product($db);
//$quotation = new Quotation($db);
//$quotationdetails = new QuotationDetails($db);
//$account = new Account($db);
$pdf=new PDF_MC_Table();


    //$successmessage=$errormessage="";
   // if(isset($_GET['id']))
    //{
      //  $quotation->getQuotationById($_GET['id']);
    //}
    //else {
          //  header("location:". $project->getProjectUrl()."quotation/quotations");
          //  exit;
   // }

//Start of the first page
$pdf->AddPage();

$pdf->SetXY(5,5);
$pdf->SetFont('Arial','B',6);
$pdf->Ln();
$pdf->SetX(5);
$pdf->SetFont('Arial','B',6);
// $pdf->SetFontSize(9);
$pdf->SetTextColor(0);// input R , G , B

$pdf->image('assets/images/logoo.jpg',179,5,15,10,'jpg');
$pdf->Ln(31);


$rowcount=7;
// $columnCounter=0;
$pdf->Ln(6);
$pdf->SetFont('Arial','B',15);
$pdf->Cell(100,8,'FA & PA System(Detection System)',0,0,'false');

$pdf->Cell(100,8,"Inspection Report",0,1,'false');
//$orderdate=$quotation->getQuotationDate();
//$billing=$account->getAccountDetail( $quotation->getCustomer());
//$salesperson=$user->getAdminUser($salesorder->getSalesPerson());
//$adjustment=$quotation->getAdjustment();
//$discount=$quotation->getDiscount();//
$width_cell=array(20,20,20,20,20,20,20,20,20,20,20);

/*$pdf->SetFillColor(193,229,252);*/ // Background color of header 
// Header starts /// 
//$pdf->Cell($width_cell[0],5,'Sr. No.',1,0,'C',true); // First header column 
//$pdf->Cell($width_cell[1],5,'Location',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[2],5,'Type',1,0,'C',true); // Third header column 
//$pdf->Cell($width_cell[1],5,'Pressure in guage',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Capacity',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Hose Pipe',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Nozzle',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Safety Pin',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Refilling date',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Due refilling date',1,0,'C',true); // Second header column
//$pdf->Cell($width_cell[1],5,'Remarks',1,0,'C',true); // Second header column
$pdf->SetFont('Arial','B',10);
$pdf->Cell(30,$rowcount,'Client Name:',1,0,'true');
$pdf->Cell(60,$rowcount,'$client',1,0,'true');

$pdf->Cell(30,$rowcount,'Report No.',1,0,'true');
$pdf->Cell(20,$rowcount,'$Report_No',1,0,'true');

$pdf->Cell(30,$rowcount,'Date',1,0,'true');
$pdf->Cell(30,$rowcount,'$date',1,0,'true');
$pdf->Ln();
  $pdf->cell(15,8,"Sr. No.",1,'true');
      $pdf->cell(15,8,"Location",1,'true');
      
      $pdf->cell(15,8,"Hooter",1,'true');
      
      $pdf->cell(15,8,"MCP",1,'true');
      $pdf->cell(15,8,"Detector",1,'true');

      $pdf->cell(25,8,"Flow Switch",1,'true');
      
      $pdf->cell(30,8,"Address in Panel",1,'true');
      
      //$pdf->cell(15,8,"PA System Instrument",1,'true');
      
    
      
      $pdf->cell(20,8,"Remarks",1,'true');
      

    //  $pdf->RowWithoutBorder(array("Sr. No.","Location","Type", "Pressure","Capacity","Hose Pipe","Nozzle", "Safety","Refilling date","Due refilling date","Remarks"));

include("config.php");
                           $sql = "SELECT * from fapa";
                            $result=mysqli_query($conn,$sql);
                            $counter=0;
                             while($row = mysqli_fetch_assoc($result))

                             {


      $location= $row['location'];
      $Hooter= $row['Hooter'];
      $MCP= $row['MCP'];
      $Detector= $row['Detector'];
      $Flow_Switch= $row['Flow_Switch'];
      $Address_in_Panel= $row['Address_in_Panel'];
    

      $Remarks= $row['Remarks'];

      $pdf->Ln();
      $pdf->SetWidths(array(10,15,15,15,15,15,15,15,15,20,20));
      //$pdf->cell(6,3,(array("$counter","$location","$type","$PressureinGauge", "$capacity","$HosePipe","$Nozzle","$SafetyPin", "$last","$next","$remark")),1,'true');
      $pdf->cell(15,8,"$counter",1,'true');
      $pdf->cell(15,8,"$location",1,'true');
      
      $pdf->cell(15,8,"$Hooter",1,'true');
      
      $pdf->cell(15,8,"$MCP",1,'true');
      $pdf->cell(15,8,"$Detector",1,'true');

      $pdf->cell(25,8,"$Flow_Switch",1,'true');
      
      $pdf->cell(30,8,"$Address_in_Panel",1,'true');
      
     
      
      
      $pdf->cell(20,8,"$Remarks",1,'true');
      


      $counter = $counter+1;
    }
//// header is over ///////
//$pdf->SetFont('Arial','',7,' \n ');
//$pdf->SetLineWidth(1);

$pdf->SetFont('Arial','',10);

$pdf->Ln(10); 
//$pdf->Cell(100,8,'For VACCIFIRE',0,0,'false');

$pdf->Ln(10); 
$pdf->SetX(5); 
$pdf->Cell(100,30,'Additional Remarks(if any)',1,'J',false);

$pdf->Cell(100,10,"For VACCIFIRE",1,1,'false');
$pdf->SetX(105); 
$pdf->Cell(100,10,"Sign",1,1,'false');
$pdf->SetX(105); 
$pdf->Cell(100,10,"Name:",1,0,'false');
//$pdf->Cell(100,8,'For Client',0,0,'false');
$pdf->Ln(10); 
$pdf->Ln(10); 
$pdf->SetX(5); 
$pdf->Cell(100,30,'Additional Remarks(if any)',1,'J',false);

$pdf->Cell(100,10,"For Client",1,1,'false');
$pdf->SetX(105); 
$pdf->Cell(100,10,"Sign",1,1,'false');
$pdf->SetX(105); 
$pdf->Cell(100,10,"Name:",1,0,'false');



// First row of data 

/*$pdf->Cell($width_cell[0],10,'1',1,0,'C',false); // First column of row 1 
$pdf->Cell($width_cell[1],10,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],10,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],10,'75',1,1,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[1],10,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],10,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],10,'75',1,1,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[1],10,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],10,'Four',1,0,'C',false); // Third column of row 1 
$pdf->Cell($width_cell[3],10,'75',1,1,'C',false); // Fourth column of row 1 
$pdf->Cell($width_cell[1],10,'John Deo',1,0,'C',false); // Second column of row 1 
$pdf->Cell($width_cell[2],10,'Four',1,0,'C',false); // Third column of row 1 */

//  First row of data is over 
//  Second row of data 
/*$pdf->Cell($width_cell[0],10,'2',1,0,'C',false); // First column of row 2 
$pdf->Cell($width_cell[1],10,'Max Ruin',1,0,'C',false); // Second column of row 2
$pdf->Cell($width_cell[2],10,'Three',1,0,'C',false); // Third column of row 2
$pdf->Cell($width_cell[3],10,'85',1,1,'C',false); // Fourth column of row 2 */
//   Sedond row is over 
//  Third row of data
/*$pdf->Cell($width_cell[0],10,'3',1,0,'C',false); // First column of row 3
$pdf->Cell($width_cell[1],10,'Arnold',1,0,'C',false); // Second column of row 3
$pdf->Cell($width_cell[2],10,'Three',1,0,'C',false); // Third column of row 3
$pdf->Cell($width_cell[3],10,'55',1,1,'C',false); // fourth column of row 3*/

$pdf->Ln(25);
$pdf->SetFont('Arial','',0);
$pdf->SetWidths(array(50,120));
//$pdf->RowWithoutBorder(array("Quotation Date :","$date"));

$pdf->Ln(8);
$pdf->SetFont('Arial','B',11);

$pdf->Ln();
$pdf->SetWidths(array(10,100,30,30,30));
//$pdf->RowWithoutBorder(array("#","Item & Description","Qty","Rate","Amount"));
$pdf->SetFont('Arial','',10);
$pdf->Ln();

//$pdf->SetFont('Arial','',10);
  //  $counter=1;
   // $details = $quotationdetails->readAllquotationDetails($quotation->getQuotationNumber());
   // foreach($details as $detailsValue)
    //{
      //$name= $detailsValue['fd_product_name'];
      //$qty= $detailsValue['fd_quantity'];
      //$rate= $detailsValue['fd_rate'];
      //$amount= $detailsValue['fd_amount'];
     // $pdf->Ln();
      //$pdf->SetWidths(array(10,100,30,30,30));
      //$pdf->RowWithoutBorder(array("$counter","$name","".$qty." pcs","Rs. ".$rate,"Rs. ".$amount));
     // $counter = $counter+1;
     //}
    //$pdf->SetFont('Arial','',10);
    //$pdf->Ln();
    //$pdf->SetWidths(array(200));
    //$pdf->RowWithoutBorderCenter(array("____________________________________________________________________________________________________"));

//$subtotal=$quotation->getSubTotal();
//$total=$quotation->getTotal();
//$pdf->Ln(10);
//$pdf->SetWidths(array(120,40,40));
//$pdf->RowWithoutBorder(array("Total in Words","Subtotal","Rs. ".$subtotal));

// if ($discount !=0)
// {
  //$pdf->Ln();
  //$pdf->SetWidths(array(120,40,40));
  //$pdf->RowWithoutBorder(array($common->getIndianCurrency($total)." Only ","Discount","Rs. ".$discount));
// }
//if ($adjustment !=0)
//{
  //$pdf->Ln();
  //$pdf->SetWidths(array(120,40,40));
  //$pdf->RowWithoutBorder(array("","Adjustment","Rs. ".$adjustment));
//}
//$pdf->Ln();
//$pdf->SetFont('Arial','B',11);
//$pdf->SetWidths(array(120,40,40));
//$pdf->RowWithoutBorder(array("","Total","Rs. ".$total));


$pdf->Ln();
$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(200));
//$pdf->RowWithoutBorder(array("NOTES #"));
$pdf->Ln();
$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(200));
//$pdf->RowWithoutBorder(array($quotation->getNotes()));
$pdf->Ln();
$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(200));
//$pdf->RowWithoutBorder(array("TERMS & CONDITIONS #"));
$pdf->Ln();
$pdf->SetFont('Arial','',10);
$pdf->SetWidths(array(200));
//$pdf->RowWithoutBorder(array($quotation->getTermsCondition()));



$pdf->SetFont('Arial','',10);
$pdf->Ln(16);
$pdf->SetWidths(array(100,100));
//$pdf->RowWithoutBorder(array("","Authorized Signature ____________________________"));
//$pdf->Cell(0,$rowcount,"",0,0,'L');

//$pdf->Output();

 $pdf->Output('I','crm/report1/d.pdf');


?>
