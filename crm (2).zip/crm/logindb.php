<?php
  
        include "config.php";
          $sql = "SELECT * from admin";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		  
        $User_Name = $_REQUEST['uname'];
        $Password = $_REQUEST['password'];
       echo"<br>user name----".$User_Name;
	   echo"<br>user pass----".$Password;
		   if(mysqli_num_rows($result) == 0)
		  {
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
					$name=$row['userid'];
					$pass=$row['password'];
					echo "<br>db name=".$name;
					echo "<br>db pass=".$pass;
					
					if($User_Name==($name) && $password==$pass)
					{
						  echo '<script>window.location.href = "dashboard.php";</script>';
					}
					else
					{
						 echo "<script type='text/javascript'>alert('Please enter correct valid id and password')</script>";
					echo '<script>window.location.href = "sign-in.html";</script>';
						
					}
		
			  }
		    
		  }
		  
        
        
        ?>