<?php 
include('config.php');
if(isset($_POST['submit'])){
  $id = $_POST['id'];
  $editfname=$_POST['editfname'];
   $editsname=$_POST['editsname'];
    $editgst=$_POST['editgst'];
    $editemail=$_POST['editemail'];
     $editphonenumber=$_POST['editphonenumber'];    

    $editaddress=$_POST['editaddress'];
     $editcity=$_POST['editcity'];
      $editstate=$_POST['editstate'];

      $update_sql= "UPDATE client SET first_name='$editfname', s_name='$editsname' ,gst='$editgst',email='$editemail',phone_number='$editphonenumber',address='$editaddress',city='$editcity',state='$editstate' WHERE id='$id'";
      if (mysqli_query($conn, $update_sql)) {

  header("location:dashboard.php");
} else {
  echo "Error updating record: " . mysqli_error($conn);
}

      
}
?>
