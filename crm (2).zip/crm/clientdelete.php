<?php
include('config.php');

/*if (isset($_POST['id']))
{
$id = $_POST['id'];

echo $id;
exit();

$result = "DELETE FROM client WHERE  id=$id";
$sql_query = mysqli_query($conn,$result);
	if($sql_query){
		echo"data has been deleted..";
	}else{
		echo "error";
	}

}*/

if(isset($_GET['id'])){
	$id = $_GET['id'];
	$result = "DELETE FROM client WHERE  id=$id";

$sql_query = mysqli_query($conn,$result);
	if($sql_query){
		header("Location: dashboard.php");
	}else{
		echo "error";
	}

}
	


?>