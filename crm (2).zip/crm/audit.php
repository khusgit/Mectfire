<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>MECT</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
     <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
    <!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> -->
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
         <a class="navbar-brand brand-logo" href="././index.html"><img src="assets/images/lon.jpg" alt="logo" /></a>
          <a class="navbar-brand brand-logo" href="index.html"><b>MECT</b></a>
        </div>

        
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <!--<div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>-->
         <!-- <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="assets/images/faces/face1.jpg" alt="image">
                  <span class="availability-status online"></span>
                </div>-->
              <!--  <div class="nav-profile-text">
                  <p class="mb-1 text-black">David Greymaax</p>
                </div>-->
             <!-- </a>
             <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-cached me-2 text-success"></i> Activity Log </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>-->
            <!--<li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="mdi mdi-email-outline"></i>
                <span class="count-symbol bg-warning"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
                <h6 class="p-3 mb-0">Messages</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face4.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Mark send you a message</h6>
                    <p class="text-gray mb-0"> 1 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face2.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Cregh send you a message</h6>
                    <p class="text-gray mb-0"> 15 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face3.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Profile picture updated</h6>
                    <p class="text-gray mb-0"> 18 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <h6 class="p-3 mb-0 text-center">4 new messages</h6>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                <i class="mdi mdi-bell-outline"></i>
                <span class="count-symbol bg-danger"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
                <h6 class="p-3 mb-0">Notifications</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-success">
                      <i class="mdi mdi-calendar"></i>
                    </div>
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Event today</h6>
                    <p class="text-gray ellipsis mb-0"> Just a reminder that you have an event today </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-warning">
                      <i class="mdi mdi-settings"></i>
                    </div>
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Settings</h6>
                    <p class="text-gray ellipsis mb-0"> Update dashboard </p>
                  </div>
                </a>-->
              <!--  <div class="dropdown-divider"></div>-->
                <a class="dropdown-item preview-item">
                 <!-- <div class="preview-thumbnail">
                    <div class="preview-icon bg-info">
                      <i class="mdi mdi-link-variant"></i>
                    </div>
                  </div>-->
                 <!-- <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Launch Admin</h6>
                    <p class="text-gray ellipsis mb-0"> New admin wow! </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <h6 class="p-3 mb-0 text-center">See all notifications</h6>
              </div>
            </li>-->

            <li class="nav-item nav-logout d-none d-lg-block">
              <!--<a class="nav-link" href="#">-->
               <!-- <i class="mdi mdi-power"></i>-->
              </a>
            </li>
              <form method="POST" action="quotationpdf.php">
<input type="submit" class="btn bg-gradient-info w-30 mt-4 mb-0" name="export" value="&darr; PDF"/>
</form>
               <a href="audit.php"><button type="Form" class="btn bg-gradient-info w-30 mt-4 mb-0">FORM</button></a>

           <!-- <li class="nav-item nav-settings d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-format-line-spacing"></i>
              </a>
            </li>-->
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
               <!-- <div class="nav-profile-image">
                  <img src="assets/images/faces/face1.jpg" alt="profile">
                  <span class="login-status online"></span>
                
                </div>-->
               <!-- <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">David Grey. H</span>
                  <span class="text-secondary text-small">Project Manager</span>
                </div>-->
              <!--  <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>-->
           <li class="nav-item">
              <a class="nav-link" href="../crm/dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="../crm/service.php">
                <span class="menu-title">Service Engineers</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="../crm/client.php">
                <span class="menu-title">Client Form</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Inspection Report</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                 <li class="nav-item"> <a class="nav-link" href="../crm/fireextinguisherreport.php">Fire Extinguisher Report</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="../crm/firehandlereport.php"> Fire Handle System</a></li>
                   <li class="nav-item"> <a class="nav-link" href="../crm/firehosereport.php">Fire Hose Reel System</a></li>
                     <li class="nav-item"> <a class="nav-link" href="../crm/fapareport.php">FA & PA System</a></li>
                  <li class="nav-item"> <a class="nav-link" href="../crm/pumpreport.php">Pump System</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="../crm/audit.php">Audit Form</a></li>

                </ul>
              </div>

            </li>
          </ul>
        </nav>
        <!-- partial -->
        
         <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="reportnumber"><b>Report No-</b></label>
                 <?php 
                include('config.php');
                $sql = "SELECT Id from audit";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
       
          </div>


                 <div class="card">
                 <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
             <div class="row">
              
                <div class="card">
                  <div class="card-body">
                    <form action="insertaudit.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><U><b>AUDIT FORM</b></U></h3>
           <table border=1>
  <tr>
    <th>Sr. No.</th>
    <th>PARTICULARS</th>
    <th>DESCRIPTION</th>
  </tr>
  <tr>
    <td>1.</td>
    <td> <label for="Occupancy">Types of Occupancy</label></td>
                            
    <td>                    
                             <label for="residential">Residential</label>
                            <input type="checkbox" id="residential" name="Occupancy" value="residential">
                             <label for="Assembly">Assembly</label>
                            <input type="checkbox" id="Assembly" name="Occupancy" value="Assembly">
                           <label for="Industrial">Industrial</label>
                            <input type="checkbox" id="Industrial" name="Occupancy" value="Industrial">
                            
                                                        
  <div class="mb-3">
        
                             <label for="educational">Educational</label>
                            <input type="checkbox" id="educational" name="Occupancy" value="educational">
                             <label for="business">Business</label>
                            <input type="checkbox" id="business" name="Occupancy" value="business">
                             <label for="storage">Storage</label>
                            <input type="checkbox" id="storage" name="Occupancy" value="storage">

  <div class="mb-3">

                             <label for="institutional">Institutional</label>
                            <input type="checkbox" id="institutional" name="Occupancy" value="institutional">
                             <label for="mercantile">Mercantile</label>
                            <input type="checkbox" id="mercantile" name="Occupancy" value="mercantile">
                             <label for="hazardous">Hazardous</label>
                            <input type="checkbox" id="hazardous" name="Occupancy" value="hazardous">
  </div></td>
  </tr>
  <tr>
    <td>2.</td>
    <td><label for="Building">Contact details of Building In-charge</label></td>
    <td><label for="name"><b>Name:</b></label>
  <input type="text" class="form-control"  id="name" name="name"  required>
  <label for="telno"><b>Tel No:</b></label>
  <input type="text" class="form-control"  id="telno" name="telno"  required>
  <label for="email"><b>Email ID:</b></label>
  <input type="text" class="form-control"  id="email" name="email"  required>
    </td>
  </tr>
  <tr>
    <td>3.</td>
    <td><label for="Fire ">Details of Fire NOC/OC</label></td>
    <td><label for="issue"><b>Issue Authority:</b></label>
  <input type="text" class="form-control"  id="issue" name="issue"  required>
  <label for="letter"><b>Letter No:</b></label>
  <input type="text" class="form-control"  id="letter" name="letter"  required>
  <label for="date">Date:</label>
  <input type="date" id="date" name="date"></td>
  </tr>
  </div>
</td>
</tr>
</table>
<br>
<table border=1>
  <tr>
    <th colspan="3">A: Fire Extinguishers:</th>
   
  </tr>
  <tr>
    <td>A1</td>
    <td>ABC</td>
    <td><input type="text" class="form-control"  id="abc" name="abc" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A2</td>
    <td>CO2</td>
    <td><input type="text" class="form-control"  id="co2" name="co2" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A3</td>
    <td>Foam
    <td><input type="text" class="form-control"  id="foam" name="foam" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A4</td>
    <td>Water</td>
    <td><input type="text" class="form-control"  id="water" name="water" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A5</td>
    <td>Others</td>
    <td><input type="text" class="form-control"  id="other" name="other" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A6</td>
    <td><label for="access ">Are they easily accessible?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="access" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="access" value="no"></td>
  </tr>
 <tr>
    <td>A7</td>
    <td><label for="access ">Are there enough fire extinguishers installed?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="install" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="install" value="no"></td>
  </tr>
   <tr>
    <td>A8</td>
    <td><label for="access ">Are all Extinguishers properly maintained?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="maintain" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="maintain" value="no"></td>
  </tr>
</td>
</tr>
</table>
</br>
<table border=1>
  <tr>
    <th colspan="3">B: Fire Tanks & Pumps:</th>
   
  </tr>
  <tr>
   
    <td>B1</td>
    <td><label for="Auto"><b><u>Fire Water Tanks:</u></b></label></br></br>
    <label for="Auto">Capacity of Underground Tank</label></br></br>
  <label for="Auto">Capacity of Overhead Tank<label><br></td>
    <td> <label for="location"><b>Litres:</b></label>
  <input type="text" class="form-control"  id="litres " name="underground"  required>
                            <label for="location"><b>Litres:</b></label>
  <input type="text" class="form-control"  id="litres" name="overhead"  required></td>
  </tr>
 <tr>
    <td>B2</td>
   <td><label for="Auto"><b><u>Main Hydrant Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow" name="flow"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head" name="head" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power" name="power"  placeholder="HP" required>
</tr>
   <tr>
    <td>B3</td>
   <td><label for="Auto"><b><u>Hydrant Jockey Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode1" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode1" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run1" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run1" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow1" name="flow1"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head1" name="head1" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power1" name="power1"  placeholder="HP" required>
</tr>
<tr>
    <td>B4</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode2" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode2" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run2" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run2" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow2" name="flow2"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head2" name="head2" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power2" name="power2"  placeholder="HP" required>
</tr>
<tr>
    <td>B5</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode3" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode3" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run3" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run3" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow3" name="flow3"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head3" name="head3" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power3" name="power3"  placeholder="HP" required>
</tr>
<tr>
    <td>B6</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode4" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode4" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run4" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run4" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow4" name="flow4"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head4" name="head4" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power4" name="power4"  placeholder="HP" required>
</tr>
<tr>
    <td>B7</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode5" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode5" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run5" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run5" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow5" name="flow5"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head5" name="head5" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power5" name="power5"  placeholder="HP" required>
</tr>
</td>
</tr>
</table>
</br>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remark"><b>Remarks/ Recommendations</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  required>  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>


  </form>
</div>
</div>
</div>
</div>






         <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
    <script>
  function select_location()
  {
   // alert("Enter in funt()");
  var data1=document.getElementById('client');
 // alert("data"+data1.value);
  var str =data1.value;
  var res =str.split("|");
 
 var Id= res[0];
 var first_name = res[1];
  var address = res[2];
  document.getElementById("location").value = address;

  //alert('ID'+Id);
 //alert(first_name);
  
  //alert('ID'+address);
  }
</script>
  </body>
</html>