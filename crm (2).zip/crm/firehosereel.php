<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>MECT</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="././index.html"><img src="assets/images/lon.jpg" alt="logo" /></a>
          <a class="navbar-brand brand-logo" href="index.html"><b>MECT</b></a>
        </div>

        
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <!--<div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>-->
         <!-- <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="assets/images/faces/face1.jpg" alt="image">
                  <span class="availability-status online"></span>
                </div>-->
              <!--  <div class="nav-profile-text">
                  <p class="mb-1 text-black">David Greymaax</p>
                </div>-->
             <!-- </a>
             <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-cached me-2 text-success"></i> Activity Log </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>-->
            <!--<li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="mdi mdi-email-outline"></i>
                <span class="count-symbol bg-warning"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
                <h6 class="p-3 mb-0">Messages</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face4.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Mark send you a message</h6>
                    <p class="text-gray mb-0"> 1 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face2.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Cregh send you a message</h6>
                    <p class="text-gray mb-0"> 15 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <img src="assets/images/faces/face3.jpg" alt="image" class="profile-pic">
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Profile picture updated</h6>
                    <p class="text-gray mb-0"> 18 Minutes ago </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <h6 class="p-3 mb-0 text-center">4 new messages</h6>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                <i class="mdi mdi-bell-outline"></i>
                <span class="count-symbol bg-danger"></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
                <h6 class="p-3 mb-0">Notifications</h6>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-success">
                      <i class="mdi mdi-calendar"></i>
                    </div>
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Event today</h6>
                    <p class="text-gray ellipsis mb-0"> Just a reminder that you have an event today </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-warning">
                      <i class="mdi mdi-settings"></i>
                    </div>
                  </div>
                  <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Settings</h6>
                    <p class="text-gray ellipsis mb-0"> Update dashboard </p>
                  </div>
                </a>-->
              <!--  <div class="dropdown-divider"></div>-->
                <a class="dropdown-item preview-item">
                 <!-- <div class="preview-thumbnail">
                    <div class="preview-icon bg-info">
                      <i class="mdi mdi-link-variant"></i>
                    </div>
                  </div>-->
                 <!-- <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                    <h6 class="preview-subject font-weight-normal mb-1">Launch Admin</h6>
                    <p class="text-gray ellipsis mb-0"> New admin wow! </p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <h6 class="p-3 mb-0 text-center">See all notifications</h6>
              </div>
            </li>-->
            <li class="nav-item nav-logout d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-power"></i>
              </a>
            </li>
           <!-- <li class="nav-item nav-settings d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-format-line-spacing"></i>
              </a>
            </li>-->
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
               <!-- <div class="nav-profile-image">
                  <img src="assets/images/faces/face1.jpg" alt="profile">
                  <span class="login-status online"></span>
                
                </div>-->
               <!-- <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">David Grey. H</span>
                  <span class="text-secondary text-small">Project Manager</span>
                </div>-->
              <!--  <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>-->
            <li class="nav-item">
              <a class="nav-link" href="../crm/dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="../crm/service.php">
                <span class="menu-title">Service Engineers</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="../crm/client.php">
                <span class="menu-title">Client Form</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Inspection Report</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="../crm/fireextinguisherreport.php">Fire Extinguisher Report</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="../crm/firehandlereport.php"> Fire Handle System</a></li>
                   <li class="nav-item"> <a class="nav-link" href="../crm/firehosereport.php">Fire Hose Reel System</a></li>
                     <li class="nav-item"> <a class="nav-link" href="../crm/fapareport.php">FA & PA System</a></li>
                  <li class="nav-item"> <a class="nav-link" href="../crm/pumpreport.php">Pump System</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="../crm/audit.php">Audit Form</a></li>

                </ul>
              </div>

            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="reportnumber"><b>Report No</b></label>
                <?php 
                include('config.php');
                $sql = "SELECT Id from firehose";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
       
          </div>

                 <div class="card">
               <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
                  
            <div class="row">
              
                <div class="card">
                  <div class="card-body">
                     <form action="insertfirehose.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><U><b>FIRE HOSE REEL SYSTEM</b></U></h3>
                  
       <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Client Name</b></label>
    <div class="mb-3">

  
   <select id="client" name="first_name" class="form-control" onChange="select_location();">
    
                          <?php
                           include("config.php");
                           $sql = "SELECT * from client";
                            $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
                            ?>
                                     <option value="<?php echo $row["id"]."|".$row["first_name"]."|".$row["address"];?>">
                                        <?php echo $row['first_name'];?>
                                      
                                     </option>
                                     <?php
                                     }
                                    ?>   
                                      </select>
                  </div>
      </div>
</div> 
<script>
   function select_location()
  {
   // alert("Enter in funt()");
  var data1=document.getElementById('client');
 // alert("data"+data1.value);
  var str =data1.value;
  var res =str.split("|");
 
 var Id= res[0];
 var first_name = res[1];
  var address = res[2];
  document.getElementById("location").value = address;
  //alert('ID'+Id);
 // alert('name'+first_name);
  
  //alert('ID'+address);
  }
</script>

            
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="location"><b>Location</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  id="location" name="location"  required> 
  </div>
</div>
</div>
  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="location"><b>Building Address</b></label>
  <div class="mb-3">
   <input type="text" class="form-control"  name="baddress"  required>  
  </div>
</div>
</div>
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="location"><b>Floor No.</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="floor"  required>  
  </div>
</div>
</div>
  
 

 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

            <div class="row">

                            
                            <label for="ball"><b>Ball Value:</b> </label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="BallValue" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="BallValue" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="BallValue" value="na">
                            </div>
                       <div class="mb-3">
  

  </div>
</div>
</div> 
<div class="field half">
                         
                            <label for="pipe"><b>Connecting Pipe: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="ConnectingPipe" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="ConnectingPipe" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="ConnectingPipe" value="na">
                             </div>
                     <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                         
                            <label for="Drum"><b>Drum: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Drum" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Drum" value="no">
                              <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Drum" value="na">
                       <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                         
                           <div class="mb-5">
                            <label for="hose"><b>Hose Reel Pipe:</b> </label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="HoseReelPipe" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="HoseReelPipe" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="HoseReelPipe" value="na">
                         <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                           <div class="mb-5">
                            <label for="nozzle"><b>Nozzle:</b> </label><br>
                             <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Nozzle" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Nozzle" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Nozzle" value="na">
                         <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                            <div class="mb-5">
                            <label for="jubil"><b>Jubil Clamp:</b> </label><br>
                             <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="JubilClamp" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="JubilClamp" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="JubilClamp" value="na">
                             <div class="mb-5">
                            
                            </div>
                          </div>
                        </div>
              
                          

No = Not Ok | A = Available | NA = Not Available | D= Damaged

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remarks"><b>Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  required>  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="aremarks"><b> Additional Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addremark"  required>  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>


  </form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

 
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>