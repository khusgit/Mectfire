<?php
  
        include "config.php";
        /*  $sql = "SELECT Customer_Id from customer";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		   $customer =  $_REQUEST['cname'];
		  $id="0";
		  if(mysqli_num_rows($result) == 0)
		  {
			  $nameid=explode(" ",$customer);
			  $id=$id."_".$nameid[0];
			  echo "id is ".$id;
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
			  $id=$row["Customer_Id"];
			  }
			  /*id concat
			 $pieces = explode("_", $id);
			$nameid=explode(" ",$customer);
			$pieces[0]=intval($pieces[0])+1;
			$id=$pieces[0]."_".$nameid[0];
			         echo "Id is ".$id;
 
		    
		  }
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
		//echo "Enter service_engg";
        $reportno =  $_REQUEST['reportnumber'];
        $fname = $_REQUEST['first_name'];
		$first_name = explode('|', $fname);
		$ffname = $first_name[1];
        $client =  $_REQUEST['client'];
        $location=$_REQUEST['location'];
        $baddress=$_REQUEST['baddress'];
        $floor=$_REQUEST['floor'];
        $glass = $_REQUEST['glass'];
        //echo "Hotter".$hooter;
		$key=$_REQUEST['key'];
		$lock=$_REQUEST['lock'];
		$rubber=$_REQUEST['rubber'];
		$branch=$_REQUEST['branch'];
		$canvas=$_REQUEST['canvas'];
		$binding=$_REQUEST['binding'];
		$Washer=$_REQUEST['Washer'];
		$Lugs=$_REQUEST['Lugs'];
		$malebinding=$_REQUEST['malebinding'];
		$Flywheel=$_REQUEST['Flywheel'];
		$femalecoupling=$_REQUEST['femalecoupling'];
		$lugss=$_REQUEST['lugss'];
		$rubberwasher=$_REQUEST['rubberwasher'];
		$pvc=$_REQUEST['pvc'];
		$nut=$_REQUEST['nut'];
		$remark=$_REQUEST['remark'];
		$addremark=$_REQUEST['addremark'];
      
        $date=date("d/m/y");
		
		
		

       
		
          
        // Performing insert query execution
        // here our table name is college
      $sql = "INSERT INTO urity_engg VALUES ('', '$reportno','$date','$ffname','$location','$baddress','$floor','$glass','$key','$lock','$rubber','$branch','$canvas','$binding','$Washer','$Lugs','$malebinding','$Flywheel','$femalecoupling','$lugss','$rubberwasher','$pvc','$nut','$remark','$addremark')";
          
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
				echo "<script type='text/javascript'>alert('Report Added Succesfully')</script>";
              header("Location: firehosereel.php");
        // echo "<script>window.close();</script>"; 
  
           
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        
        
        ?>