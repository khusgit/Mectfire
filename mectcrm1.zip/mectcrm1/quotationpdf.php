<?php 
require('report/mc_table.php');
require('config.php');
require('vendor/autoload.php');

$client=$_GET['client'];
$predate=$_GET['date'];
$todate=date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Example 1</title>
    <link rel="stylesheet" href="stylle.css" media="all" />
  </head>
  <body>
    <header class="clearfix">
      <div id="logo">
        <img src="lon.jpg">
      </div>
      <h1>MECT FIRE</h1>
      <!-- <div id="company" class="clearfix">
        <div>Company Name</div>
        <div>455 Foggy Heights,<br /> AZ 85004, US</div>
        <div>(602) 519-0450</div>
        <div><a href="mailto:company@example.com">company@example.com</a></div>
      </div> -->
      <div id="project">
        <div><span>CLIENT</span> <?php echo $client;?></div>
      </div>
    </header>
    <main>
      <table>
        <thead>
          <tr>
           <th class="service">Client</th>
            <th class="desc">Location</th>
            <th >Type</th>
            <th>PressureinGauge</th>
            <th>capacity</th>
            <th>HosePipe</th>
            <th>Nozzle</th>
            <th>SafetyPin</th>
            <th>last</th>
            <th>next</th>
            <th>remark</th>
          </tr>
        </thead>
        <tbody>


<?php  



$sql="SELECT * FROM `mect1` WHERE `client`='$client' AND `date` BETWEEN '$predate' AND '$todate' ";
$result=mysqli_query($conn,$sql);
$counter=0;
  while($row = mysqli_fetch_assoc($result))
    { 
      $client = $row['client'];
        $location= $row['location'];
      $type= $row['type'];
      $PressureinGauge= $row['pressure_in_gauge'];
      $capacity= $row['capacity'];
      $HosePipe= $row['hose_pipe'];
      $Nozzle= $row['nozzle']; 
      $SafetyPin= $row['sefety_pin'];
      $last= $row['Last_refiling'];
      $next= $row['next_refiling'];
      $remark= $row['remark'];
    

        
      
        
          @$html.='<tr>';
            $html.='<td class="service"> '. $client.'</td>';
            $html.='<td class="desc">'. $location.'</td>';
            $html.='<td class="unit">'. $type.'</td>';
            $html.='<td class="qty">'. $PressureinGauge.'</td>';
            $html.='<td class="total">'. $capacity.'</td>';
            $html.='<td class="service"> '. $HosePipe.'</td>';
            $html.='<td class="desc">'. $Nozzle.'</td>';
            $html.='<td class="unit">'. $SafetyPin.'</td>';
            $html.='<td class="qty">'. $last.'</td>';
            $html.='<td class="total">'. $next.'</td>';
            $html.='<td class="total">'. $remark.'</td>';
          
          $html.='</tr>';
          
        $html.='</tbody>';
        }
      $html.='</table>';
      



    
   $mpdf = new \Mpdf\Mpdf();
    $mpdf->WriteHTML($html);
    $file = time().'.pdf';
    $mpdf->output($file,'D');


?>


<footer>
      Invoice was created on a computer and is valid without the signature and seal.
    </footer>
  </body>
</html>