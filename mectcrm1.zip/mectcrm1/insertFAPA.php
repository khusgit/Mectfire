<?php
  
        include "config.php";
        /*  $sql = "SELECT Customer_Id from customer";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		   $customer =  $_REQUEST['cname'];
		  $id="0";
		  if(mysqli_num_rows($result) == 0)
		  {
			  $nameid=explode(" ",$customer);
			  $id=$id."_".$nameid[0];
			  echo "id is ".$id;
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
			  $id=$row["Customer_Id"];
			  }
			  /*id concat
			 $pieces = explode("_", $id);
			$nameid=explode(" ",$customer);
			$pieces[0]=intval($pieces[0])+1;
			$id=$pieces[0]."_".$nameid[0];
			         echo "Id is ".$id;
 
		    
		  }
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
		//echo "Enter service_engg";
		
		
		$x=$_REQUEST['cylinder'];
		$cid=$_REQUEST['client_id'];
		if($x=='yes')
		{
	    
       @$reportno =  $_REQUEST['reportnumber'];
       $fname = $_REQUEST['first_name'];
		
		$alocation=$_REQUEST['location'];
        $baddress=$_REQUEST['Society_Name'];
        $floor=$_REQUEST['floor'];
		$wing=$_REQUEST['wings'];
        $hooter = $_REQUEST['hooter'];
        //echo "Hotter".$hooter;
		$MCP=$_REQUEST['MCP'];
		$Detector=$_REQUEST['Detector'];
		$FlowSwitch=$_REQUEST['FlowSwitch'];
		$address_panel=$_REQUEST['addressin'];
		$remark=$_REQUEST['remark'];
		//$remark=$_REQUEST['remark'];
		$addremark=$_REQUEST['addremark'];
        //$Email_Id = $_REQUEST['email'];
        //$addres = $_REQUEST['address'];
        //$Gender = $_REQUEST['gender'];
       $date=date("Y/m/d");
		$sql = "INSERT INTO fapa VALUES ('', '$reportno','$date','$fname','$alocation','$baddress','$floor','$wing','$hooter','$MCP','$Detector','$FlowSwitch','$address_panel','$remark','$addremark')";
        
		}
		else
		{
			   
       @$reportno =  $_REQUEST['reportnumber'];
       $fname = $_REQUEST['first_name'];
		
		$alocation=$_REQUEST['location'];
        $baddress=$_REQUEST['Society_Name'];
        $floor=$_REQUEST['floor'];
		$wing=$_REQUEST['wings'];
        $hooter = 'No';
        //echo "Hotter".$hooter;
		$MCP='No';
		$Detector='No';
		$FlowSwitch='No';
		$address_panel='No';
		$remark='No';
		//$remark=$_REQUEST['remark'];
		$addremark='No';
        //$Email_Id = $_REQUEST['email'];
        //$addres = $_REQUEST['address'];
        //$Gender = $_REQUEST['gender'];
         $date=date("Y/m/d");
		$sql = "INSERT INTO fapa VALUES ('', '$reportno','$date','$fname','$alocation','$baddress','$floor','$wing','$hooter','$MCP','$Detector','$FlowSwitch','$address_panel','$remark','$addremark')";
		}
		

       
		
          
        // Performing insert query execution
        // here our table name is college
          
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
				echo "<script type='text/javascript'>alert('Report Added Succesfully')</script>";
                 header("Location: audit.php?ID=$cid&wing=$wing&floor=$floor");
        // echo "<script>window.close();</script>"; 
  
           
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        
        
        ?>