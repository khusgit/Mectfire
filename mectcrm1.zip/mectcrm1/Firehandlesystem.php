     <?php include 'include/header.php';?>
	 <!-- partial -->
         <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="report"><b>Report No</b></label>
					<label name="reportnumber">
            <?php 
                include('config.php');
                $sql = "SELECT Id from urity_engg";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       </label>
          </div>

                  <div class="card">
                <label for="date"><b> Date</b>
                 <label><?php echo date('d/m/y');?></label>
               </label>
                </div>
              </div>
                 
            <div class="row">
              
                <div class="card">
                  <div class="card-body">
                     <form action="insertfirehandle.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><b><u>Fire Handle System</u></b></h3>
                  
       <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Client Name</b></label>
						
    <div class="mb-3">

  
 
                          <?php
                           include("config.php");
						   $id=$_GET['ID'];
                           $sql = "SELECT * from client where id=$id";
                            $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
								 
                            ?>
                         <input type="text" class="form-control"  id="first_name" name="first_name" readonly value="<?php echo $row['first_name'];?>"required>  
		            
                 
                  </div>
      </div>
</div>
	<input type="text" class="form-control"  id="client_id" name="client_id" value=<?php echo $_GET['ID'];?> readonly hidden>  
               <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Location</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="location" name="location" readonly value="<?php echo $row['address'];?>"required>  
							
					</div>
			</div>
		</div>
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Society Name</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="Society_Name" name="Society_Name" value="<?php echo $row['Bulding_Name'];?>"readonly required>  
					</div>
			</div>
		</div>

  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Wings</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="wing" name="wing" value="<?php echo $wing=chr($_GET['wing'])." Wing";?>" readonly required>  	
   
                </div>
      </div>
</div> 
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Floor</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="floor" name="floor"value="<?php echo  	$_GET['floor'] ;?>" readonly required>  	
   
                </div>
      </div>
</div>
							 <?php }?>
							  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
 
   <div ><b><u>Fire Handle System</u></b>
      <input type="radio" id="show" name="cylinder" value="yes" onChange="showhide();">
       <label for="html">Yes</label>
      <input type="radio" id="hide" name="cylinder" value="no" onChange="showhide();">
       <label for="css">No</label><br>
      </br>
    </div>
<input type="text" class="form-control"  id="wings" name="wings" value="<?php echo $_GET['wing'];?>" readonly required hidden>  		
</div>
</div>
		<div  id="formfire" hidden> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

            <div class="row">
               <label for="last_name"><b><U>Hydrant Hose Box</U></b></label>
                               <div class="mb-6">
                            <label for="Hooter"><b>Glass: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="glass" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="glass" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="glass" value="na">
                            
  <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
               
                            <label for="key"><b>Key & Glass: </b></label><br>
                              <div class="mb-5">
                            <label for="A">A</label>
                            <input type="checkbox" id="a" name="key" value="a">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="key" value="na">
                            
  <div class="mb-5">
  

  </div>
</div>
</div>
<div class="field half">
               
                            <label for="lock"><b>Lock: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="lock" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="lock" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="lock" value="na">
                            
  <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
               
                            <label for="rubber"><b>Rubber: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="rubber" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="rubber" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="rubber" value="na">
                            
  <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                            <label for="branch"><b>Branch Pipe: </b></label><br>
                              <div class="mb-5">
                            <label for="A">A</label>
                            <input type="checkbox" id="a" name="branch" value="a">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="branch" value="na">
  <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

            <div class="row">
               <label for="canvas"><b><U>Canvas Hose</U></b></label>
                             <div class="mb-6"> 
                            <label for="canvas"><b>Hose Pipe: </b></label><br>
                            <div class="mb-5">   
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="canvas" value="ok">
                            <label for="No"> No</label>
                            <input type="checkbox" id="no" name="canvas" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="canvas" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
     
               <label for="canvas"><b><U>Canvas Hose</U></b></label>
                               <div class="mb-6">
                                <label for="female"><b><U>Female</U></b></label>
                                    <div class="mb-5">
                            <label for="binding"><b>Binding: </b></label><br>
                                    <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="binding" value="ok">
                              <label for="No"> No</label>
                            <input type="checkbox" id="no" name="binding" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="binding" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
     <div class="field half">
                            <label for="binding"><b>Washer: </b></label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Washer" value="ok">
                              <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Washer" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Washer" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
     <div class="field half">
                            <label for="binding"><b>Lugs: </b></label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Lugs" value="ok">
                              <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Lugs" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Lugs" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
     <div class="field half">
               <label for="canvas"><b><U>Canvas Hose</U></b></label>
                               <div class="mb-6">
                            <label for="canvas"><b>Male Binding: </b></label><br>
            
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="malebinding" value="ok">
                              <label for="No"> No</label>
                            <input type="checkbox" id="no" name="malebinding" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="malebinding" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
     <div class="field half">
               <label for="canvas"><b><U>Hydrant Valve(Stand Post & Landing Valve)</U></b></label>
                               <div class="mb-6">
                            <label for="canvas"><b>Flywheel: </b></label><br>
            
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Flywheel" value="ok">
                              <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Flywheel" value="no">
                            <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Flywheel" value="na">
 
  <div class="mb-5">
  

  </div>
</div>
</div>
<div class="field half">
                            <label for="MCP"><b>Female Coupling:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="femalecoupling" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="femalecoupling" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="femalecoupling" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="femalecoupling" value="missing">

  <div class="mb-5">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Lugs</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="lugss" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="lugss" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="lugss" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="lugss" value="missing">

  <div class="mb-5">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Rubber Washer:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="rubberwasher" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="rubberwasher" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="rubberwasher" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="rubberwasher" value="missing">

  <div class="mb-5">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Pvc Cap:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="pvc" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="pvc" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="pvc" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="pvc" value="missing">

  <div class="mb-5">

  </div>
</div>

<div class="field half">
                            <label for="MCP"><b>Nut:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="nut" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="nut" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="nut" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="nut" value="missing">

  <div class="mb-5">

  </div>
</div>

No = Not Ok | A = Available | NA = Not Available | D= Damaged

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remarks"><b>Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  >  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="addremark"><b> Additional Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addremark"  >  
  </div>
</div>
</div> 
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>


  </form>
</div>
</div>
</div>
</div>

 
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
  <script>
  function showhide()
{
//	var x=document.getElementById('id').checked;
	
	    if(document.getElementById('show').checked) 
		{   
           var selectedValue = document.getElementById('show').value;  
		   document.getElementById('formfire').hidden=false;
         //  alert("Selected Radio Button is: " + selectedValue);    
        }
		if(document.getElementById('hide').checked) 
		{   
           var selectedValue = document.getElementById('hide').value;  
		    document.getElementById('formfire').hidden=true;
         // alert("Selected Radio Button is: " + selectedValue);    
		}  		
}
</script>
</html>