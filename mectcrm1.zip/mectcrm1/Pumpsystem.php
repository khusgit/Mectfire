     <?php include 'include/header.php';?>        <!-- partial -->
       <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="reportnumber"><b>Report No</b></label>
            <?php 
                include('config.php');
                $sql = "SELECT Id from audit";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
          </div>

                 <div class="card">
                 <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
             <div class="row">
              
                <div class="card">
                  <div class="card-body">
                    <form action="insertpump.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><U><b>PUMP SYSTEM</b></U></h3>
                  
       <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Client Name</b></label>
    <div class="mb-3">

  
    <select id="client" name="first_name" class="form-control" onChange="select_location();">
    
                          <?php
                           include("config.php");
                           $sql = "SELECT * from client";
                            $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
                            ?>
                                     <option value="<?php echo $row["id"]."|".$row["first_name"]."|".$row["address"];?>">
                                        <?php echo $row['first_name'];?>
                                      
                                     </option>
                                     <?php
                                     }
                                    ?>   
                    </select>
                  </div>
      </div>
</div> 
<script>
  function select_location()
  {
   // alert("Enter in funt()");
  var data1=document.getElementById('client');
 // alert("data"+data1.value);
  var str =data1.value;
  var res =str.split("|");
 
 var Id= res[0];
 var first_name = res[1];
  var address = res[2];
  document.getElementById("location").value = address;
  //alert('ID'+Id);
 // alert('name'+first_name);
  
  //alert('ID'+address);
  }
</script>
  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="location"><b>Location</b></label>
  <div class="mb-3">
  
  
  <input type="text" class="form-control"  id="location" name="location"  required>  
  </div>
</div>
</div>
        

            <div class="row">    
       <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="pump"><b>Pump Description</b></label>
    <div class="mb-3">
       
          
  
   <select id="sel" name="pump" class="form-control" onchange="toggle()">
    
                        <option value="1" selected >Hydrant Jockey Pump</option>
                        <option value="2">Hydrant Main Pump</option>
                        <option value="3">Sprinkler Jockey Pump</option>   
                        <option value="4">Sprinkler Main Pump</option>
                        <option value="5" >Diesel Pump</option>
                        <option value="6">Booster Pump</option>    
                    </select>
                  </div>
      </div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="pressurekg"><b>Pressure(in Kg/cm)</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="pressurekg"  required>  
  </div>
</div>
</div> 


  
 

            <div class="row">   
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

      <div class="field half">
              
                            <label for="Hooter"><b>Mode of Operation: </b></label><br>
                              <div class="mb-3">
                            <label for="Auto">Auto</label>
                            <input type="checkbox" id="ok" name="Mode" value="ok">
                             <label for="Manual"> Manual</label>
                            <input type="checkbox" id="no" name="Mode" value="no">
                           
  <div class="mb-3">
  

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Pressure Drop Check:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="pdrop" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="pdrop" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="pdrop" value="na">
                          
  <div class="mb-3">

  </div>
</div>
</div> 
                         <div class="field half">
                            <label for="MCP"><b>Gland:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="gland" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="gland" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="gland" value="na">

                          
  <div class="mb-5">

  </div>
</div>
</div> 
                    <div class="field half">
                            <label for="MCP"><b>Bearing:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="bearing" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="bearing" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="bearing" value="na">
                          
  <div class="mb-3">

  </div>
</div>

       <div class="field half">
                            <label for="MCP"><b>Vibration:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="vibration" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="vibration" value="no">
                           <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="vibration" value="na">
  <div class="mb-3">

  </div>

</div>
</div> 




<div id="cont" style="display:block; ">  
                     
        
            <div class="row">
               <label for="last_name"><b><U>Diesel Pump System</U></b></label>
                               <div class="mb-2">

            <div class="row">
              <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
  <label for="battery"><b>Battery Voltage</b></label>
  <div class="mb-3">
 <input type="text" class="form-control"  name="battery"  required>  
  </div>
</div>
</div> 
                            <label for="coolant"><b>Coolant Level :</b></label><br>
                                 <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="coolant" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="coolant" value="low">
                            
 
  <div class="mb-3">
  

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Engine Oil:</b> </label><br>
                            <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="engine" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="engine" value="low">

  <div class="mb-3">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Fuel Level:</b> </label><br>
                            <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="fuel" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="fuel" value="low">

  <div class="mb-3">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Oil Filter:</b> </label><br>
                            <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="oilfilter" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="oilfilter" value="low">

  <div class="mb-3">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Air Filter:</b> </label><br>
                            <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="airfilter" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="airfilter" value="low">

  <div class="mb-3">

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>Diesel Filter:</b> </label><br>
                            <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="dieselfilter" value="ok">
                             <label for="Low"> Low</label>
                            <input type="checkbox" id="low" name="dieselfilter" value="low">

  <div class="mb-3">

  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remark"><b>Remarks</b></label>
  <div class="mb-6">
  
  
   <input type="text" class="form-control"  name="remark"  required>  
  </div>
</div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="addremark"><b> Additional Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addremark"  required>  
  </div>
</div>
</div> 
</div>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
      <div class="row">
   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>
</div>
</div>
  </form>
</div>
</div>
</div>
</div>




 
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
  <script>
    function toggle() {
        var cont = document.getElementById('cont');
        if (cont.style.display == 'block') {
            cont.style.display = 'none';
        }
        else {
            cont.style.display = 'block';
        }
    }
</script>
</html>