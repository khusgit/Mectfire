<?php 
include "config.php";
if(isset($_POST['submit']))
{
 
		$userid=$_POST['exampleInputEmail1'];
       $oldPass=$_POST['oldInputPassword1'];
	   $newPass=$_POST['newInputPassword1'];
		$date=date("d/m/y");
		
		
		

       
		
          
        // Performing insert query execution
        // here our table name is college
       // $sql = "INSERT INTO admin VALUES ('','$FName', '$Mobile_No','$Email_Id','$Pass','$date')";
         $sql = "UPDATE admin SET Password='$newPass' WHERE  userid='$userid'"; 
        if(mysqli_query($conn, $sql)){
					
					
						  echo '<script>window.location.href = "index.php";</script>';
					}
					else
					{
						 echo "<script type='text/javascript'>alert('Please enter correct data')</script>";
					echo '<script>window.location.href = "changepassword.php";</script>';
						
					}
		
			  }
		    
		  

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>MECT</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">
      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth">
          <div class="row flex-grow">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-light text-left p-5">
                <div class="brand-logo">
                  <h2>MECT</h2>
                </div>
                <h4>Change Password</h4>
                
                <form class="pt-3" action="changepassword.php" method="post">
				  
                  <div class="form-group">
                    <input type="email" class="form-control form-control-lg" id="exampleInputEmail1" name="exampleInputEmail1" placeholder="Email id" required>
                  </div>
                  <div class="form-group">
                   <input type="password" class="form-control form-control-lg" id="oldInputPassword1" name="oldInputPassword1"
					placeholder="Old Password"required>
                  </div>
				  <div class="form-group">
                   <input type="password" class="form-control form-control-lg" id="newInputPassword1" name="newInputPassword1"
					placeholder="New Password"required onChange="checkpass();">
                  </div>
                  <div class="mt-3">
                    	<input type="submit" class="btn bg-gradient-info w-30 mt-4 mb-0 "   name="submit" value="Change Password"/>
                  </div>
                  </form>
              </div>
             </div>
          </div>
        </div>
		<script>
		function checkpass()
		{
			//alert("Enter in checkpass");
		var oldpass=document.getElementById('oldInputPassword1').value;	
		var newpass=document.getElementById('newInputPassword1').value;	
		//alert (oldpass);
		//alert(newpass);
		if(oldpass==newpass)
		{
			//alert("password are same");
		}
		else{
			alert("Enter same password");
			}
		
		}
		
		</script>
        <!-- content-wrapper ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
  </body>
</html>