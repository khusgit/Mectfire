     <?php include 'include/header.php';?>        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                 <!-- <li class="breadcrumb-item"><a href="#"> Vender</a></li>-->
                  <!--<li class="breadcrumb-item active" aria-current="page">Add Vender</li>-->
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                      <form method="POST" action="insertclient.php">
                <h3 class="font-weight-bolder text-info text-gradient"><U><b>Add New Client</b></U></h3>
                    <p class="card-description">  </p>
                    
                         <div class="container-fluid py-4">
      <div class="row">
       
        <div class="mb-5">
<h4 class="font-weight-bolder text-info text-gradient"><U><b>Add New Client</b></U></h4>
    
          
            <div class="row">
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
  
        <label for="lname"><b>Client  Name</b></label>
           <div class="row">

				<div class="mb-3">
				<input type="client" class="form-control" id="client" name="first_name" required>
			</div>
		</div>
		</div>
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
					<label for="mobile"><b>Mobile</b></label>
							<div class="mb-3">
							  
							  
							   <input type="text" class="form-control"  name="phone_number"  required>  
							</div>
			</div>
		</div> 
		 
 
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="email"><b>Email</b></label>
					<div class="mb-3">
						  
						  
						   <input type="text" class="form-control"  name="email"  >  
					</div>
			</div>
		</div> 
					   
				  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
							<div class="row">
							<label for="email"><b>GST Number</b></label>
								<div class="mb-3">
								  <input type="text" class="form-control"  name="gst" >
								</div>
				             </div>
				</div>
			


				 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
							<div class="row">
								<label for="address"><b> Location</b></label>
									<div class="mb-3">
										<input type="text" class="form-control"  name="address" required>
									</div>
							</div>
				</div>
			
    			<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
					<div class="row">
							<label for="lname"><b>Society Name</b></label>
						<div class="mb-3">
							<input type="text" class="form-control"  name="s_name" required>
						</div>
					</div>
				</div>
				
				
				<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
					<div class="row">
							<label for="lname"><b>Number Of Wing</b></label>
						<div class="mb-3">
							<input type="text" class="form-control"  name="wing" required>
						</div>
					</div>
				</div>   
				
				
				<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
					<div class="row">
							<label for="lname"><b>Number Of  Floor</b></label>
						<div class="mb-3">
							<input type="text" class="form-control"  name="floor" required>
						</div>
					</div>
				</div>
				
				
				<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
						<div class="row">
							<label for="address"><b> City</b></label>
								<div class="mb-3">
								<input type="text" class="form-control"  name="city" required>
								</div>
						</div>
			    </div>

  
				<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
						<div class="row">
							<label for="address"><b> Postal Code</b></label>
								<div class="mb-3">
								<input type="text" class="form-control"  name="pcode" required>
								</div>
						</div>
			    </div>


				<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
						<div class="row">
							<label for="address"><b> State</b></label>
								<div class="mb-3">
								<input type="text" class="form-control"  name="state" required>
								</div>
						</div>
			    </div>

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>

  
</div>
</div>
</div>
</div>
 	   
              </div>
      </div>
</div>      

          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>