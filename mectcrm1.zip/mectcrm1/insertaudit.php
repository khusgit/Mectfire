<?php
  
        include "config.php";
        /*  $sql = "SELECT Customer_Id from customer";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		   $customer =  $_REQUEST['cname'];
		  $id="0";
		  if(mysqli_num_rows($result) == 0)
		  {
			  $nameid=explode(" ",$customer);
			  $id=$id."_".$nameid[0];
			  echo "id is ".$id;
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
			  $id=$row["Customer_Id"];
			  }
			  /*id concat
			 $pieces = explode("_", $id);
			$nameid=explode(" ",$customer);
			$pieces[0]=intval($pieces[0])+1;
			$id=$pieces[0]."_".$nameid[0];
			         echo "Id is ".$id;
 
		    
		  }
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
		//echo "Enter service_engg";
        @$Report_No =  $_REQUEST['reportnumber'];
        //$fname = $_REQUEST['first_name'];
		//$first_name = explode('|', $fname);
		//$ffname = $first_name[1];

        
       
      
        $Occupancy=$_REQUEST['Occupancy'];
      
		$name=$_REQUEST['name'];
		$cid=$_REQUEST['cid'];
		$floor=$_REQUEST['floor'];
		$wing=$_REQUEST['wing'];
		$telno=$_REQUEST['telno'];
        $email=$_REQUEST['email'];
		$issue=$_REQUEST['issue'];
		$letter=$_REQUEST['letter'];
        $dates=$_REQUEST['date'];
		$abc=$_REQUEST['abc'];
		$co2=$_REQUEST['co2'];
		$foam=$_REQUEST['foam'];
		$water=$_REQUEST['water'];
        $other=$_REQUEST['other'];
		$access=$_REQUEST['access'];
		$install=$_REQUEST['install'];
        $maintain=$_REQUEST['maintain'];
		$underground=$_REQUEST['underground'];
		$overhead=$_REQUEST['overhead'];
		$mode=$_REQUEST['mode'];
		$run=$_REQUEST['run'];
        $flow=$_REQUEST['flow'];
		$head=$_REQUEST['head'];
		$power=$_REQUEST['power'];
       	$mode1=$_REQUEST['mode1'];
		$run1=$_REQUEST['run1'];
        $flow1=$_REQUEST['flow1'];
		$head1=$_REQUEST['head1'];
		$power1=$_REQUEST['power1'];
		$mode2=$_REQUEST['mode2'];
		$run2=$_REQUEST['run2'];
        $flow2=$_REQUEST['flow2'];
		$head2=$_REQUEST['head2'];
		$power2=$_REQUEST['power2'];
		$mode3=$_REQUEST['mode3'];
		$run3=$_REQUEST['run3'];
        $flow3=$_REQUEST['flow3'];
		$head3=$_REQUEST['head3'];
		$power3=$_REQUEST['power3'];
		$mode4=$_REQUEST['mode4'];
		$run4=$_REQUEST['run4'];
        $flow4=$_REQUEST['flow4'];
		$head4=$_REQUEST['head4'];
		$power4=$_REQUEST['power4'];
		$mode5=$_REQUEST['mode5'];
		$run5=$_REQUEST['run5'];
        $flow5=$_REQUEST['flow5'];
		$head5=$_REQUEST['head5'];
		$power5=$_REQUEST['power5'];
		$remark=$_REQUEST['remark'];
        $date=date("Y/m/d");
		
		
		

       
		
          
        // Performing insert query execution
        // here our table name is college
      $sql = "INSERT INTO audit VALUES ('','$Report_No','$date','$Occupancy','$name','$telno','$email','$issue','$letter','$dates','$abc','$co2','$foam','$water','$other','$access','$install','$maintain','$underground','$overhead','$mode','$run','$flow','$head','$power','$mode1','$run1','$flow1','$head1','$power1','$mode2','$run2','$flow2','$head2','$power2','$mode3','$run3','$flow3','$head3','$power3','$mode4','$run4','$flow4','$head4','$power4','$mode5','$run5','$flow5','$head5','$power5','$remark')";
          
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
				echo "<script type='text/javascript'>alert('Report Added Succesfully')</script>";
               header("Location: Form1.php?ID=$cid&floor=$floor&wing=$wing");
        // echo "<script>window.close();</script>"; 
  
           
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        
        
        ?>