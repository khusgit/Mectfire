<?php

/*
$servername = "localhost";
$username = "adctegwn_mect";
$password = "mect@1234";
$database = "adctegwn_mect";*/
// Create connection
$servername = "localhost";
$username = "root";
$password = "root";
$database = "mect1";
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("login failed: " . $conn->connect_error);
}
//echo "login successfully";
?>