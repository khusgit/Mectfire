     <?php include 'include/header.php';?>        <!-- partial -->
  <div style= "width: 1200px; white-space: nowrap; overflow-x: scroll;">
          <div class="card-header pb-0">
          <h3 class="font-weight-bolder text-info text-gradient">Audit Form Report</h3>
            
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                        <th scope="col">Report No.</th>
                      <th scope="col">Occupancy</th>
                      <th scope="col">Name</th>
                      <th scope="col">Tel No.</th>
                      <th scope="col">Email ID</th>
            <th scope="col">Issue Authority</th>
            <th scope="col">Letter No.</th>
            <th scope="col">Date</th>
                      <th scope="col">ABC</th>
         <th scope="col">CO2</th>
          <th scope="col">Foam</th>
           <th scope="col">Water</th> 
                      <th scope="col">Others</th> 
                       <th scope="col">Are they easily accessible?</th> 
                        <th scope="col">Are there enough fire extinguishers installed?</th> 
           <th scope="col">Are all Extinguishers properly maintained?</th> 
           <th scope="col">Capacity of Underground Tank</th> 
            <th scope="col">Capacity of Overhead Tank</th> 
             <th scope="col">Main Hydrant Pump:(Mode)</th> 
              <th scope="col">Run Test Done?</th> 
               <th scope="col">Hydrant Jockey Pump:(Mode)</th> 
               <th scope="col">Run Test Done?</th>
                <th scope="col">Main Sprinkler Pump:(Mode)</th> 
              <th scope="col">Run Test Done?</th> 
               <th scope="col">Main Sprinkler Pump:(Mode)</th> 
               <th scope="col">Run Test Done?</th> 
                <th scope="col">Main Sprinkler Pump:(Mode)</th> 
              <th scope="col">Run Test Done?</th> 
               <th scope="col">Main Sprinkler Pump:(Mode)</th> 
              <th scope="col">Run Test Done?</th>  
                           
       <th scope="col">Remarks</th>
                   
          
                    </tr>
                  </thead>
                  <tbody>
   
        <?php
        include "config.php";
       $date=date('d/m/y');
          $sql = "SELECT * FROM audit";
          $result=mysqli_query($conn,$sql);
     
              while($row = mysqli_fetch_assoc($result))
            {
        ?>
          <tr>
             <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['id'];?></h6>
                            
                          </div>
                        </div>
                      </td>
          <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['Occupancy'];?></h6>
                            
                          </div>
                        </div>
                      </td>
          <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['name'];?></h6>
                            
                          </div>
                        </div>
                      </td>
          <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['telno'];?></h6>
                            
                          </div>
                        </div>
                      </td>
          <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['email'];?></h6>
                            
                          </div>
                        </div>
                      </td>
          <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['issue'];?></h6>
                              </div>
                        </div>
                      </td>
            <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['letter'];?></h6>
                            
                          </div>
                        </div>
                      </td>
             <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['dates'];?></h6>
                            
                          </div>
                        </div>
                      </td>
            <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['abc'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['co2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['foam'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['water'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['other'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['access'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['install'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['maintain'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['underground'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['overhead'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode1'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run1'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow1'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head1'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power1'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power2'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode3'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run3'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow3'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head3'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power3'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode4'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run4'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow4'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head4'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power4'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                      <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['mode5'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['run5'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['flow5'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['head5'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['power5'];?></h6>
                            
                          </div>
                        </div>
                      </td>
                       <td>
                        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['remark'];?></h6>
                            
                          </div>
                        </div>
                      </td>

                      </tr>  
   
                         
            <?php }?>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>



 <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>