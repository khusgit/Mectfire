     <?php include 'include/header.php';?>
     <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
        <!-- partial -->
        
         <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="reportnumber"><b>Report No-</b></label>
                 <?php 
                include('config.php');
                $sql = "SELECT Id from audit";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
       
          </div>


                 <div class="card">
                 <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
             <div class="row">
              
                <div class="card">
                  <div class="card-body">
                    <form action="insertaudit.php" method="POST" id="makepdf">
                    <h3 class="font-weight-bolder text-info text-gradient"><U><b>AUDIT FORM</b></U></h3>
           <table border=1>
  <tr>
    <th>Sr. No.</th>
    <th>PARTICULARS</th>
    <th>DESCRIPTION</th>
  </tr>
  <tr>
    <td>1.</td>
    <td> <label for="Occupancy">Types of Occupancy</label></td>
                            
    <td>                    
                             <label for="residential">Residential</label>
                            <input type="checkbox" id="residential" name="Occupancy" value="residential">
                             <label for="Assembly">Assembly</label>
                            <input type="checkbox" id="Assembly" name="Occupancy" value="Assembly">
                           <label for="Industrial">Industrial</label>
                            <input type="checkbox" id="Industrial" name="Occupancy" value="Industrial">
                            
                                                        
  <div class="mb-3">
        
                             <label for="educational">Educational</label>
                            <input type="checkbox" id="educational" name="Occupancy" value="educational">
                             <label for="business">Business</label>
                            <input type="checkbox" id="business" name="Occupancy" value="business">
                             <label for="storage">Storage</label>
                            <input type="checkbox" id="storage" name="Occupancy" value="storage">

  <div class="mb-3">

                             <label for="institutional">Institutional</label>
                            <input type="checkbox" id="institutional" name="Occupancy" value="institutional">
                             <label for="mercantile">Mercantile</label>
                            <input type="checkbox" id="mercantile" name="Occupancy" value="mercantile">
                             <label for="hazardous">Hazardous</label>
                            <input type="checkbox" id="hazardous" name="Occupancy" value="hazardous">
  </div></td>
  </tr>
  <tr>
    <td>2.</td>
    <td><label for="Building">Contact details of Building In-charge</label></td>
    <td><label for="name"><b>Name:</b></label>
  <input type="text" class="form-control"  id="name" name="name"  required>
  <label for="telno"><b>Tel No:</b></label>
  <input type="text" class="form-control"  id="telno" name="telno"  required>
  <label for="email"><b>Email ID:</b></label>
  <input type="text" class="form-control"  id="email" name="email"  required>
    </td>
  </tr>
  <tr>
    <td>3.</td>
    <td><label for="Fire ">Details of Fire NOC/OC</label></td>
    <td><label for="issue"><b>Issue Authority:</b></label>
  <input type="text" class="form-control"  id="issue" name="issue"  required>
  <label for="letter"><b>Letter No:</b></label>
  <input type="text" class="form-control"  id="letter" name="letter"  required>
  <label for="date">Date:</label>
  <input type="date" id="date" name="date"></td>
  </tr>
  </div>
</td>
</tr>
</table>
<br>
<table border=1 >
  <tr>
    <th colspan="3">A: Fire Extinguishers:</th>
   
  </tr>
  <tr>
    <td>A1</td>
    <td>ABC</td>
    <td><input type="text" class="form-control"  id="abc" name="abc" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A2</td>
    <td>CO2</td>
    <td><input type="text" class="form-control"  id="co2" name="co2" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A3</td>
    <td>Foam
    <td><input type="text" class="form-control"  id="foam" name="foam" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A4</td>
    <td>Water</td>
    <td><input type="text" class="form-control"  id="water" name="water" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A5</td>
    <td>Others</td>
    <td><input type="text" class="form-control"  id="other" name="other" placeholder="nos"  required></td>
  </tr>
  <tr>
    <td>A6</td>
    <td><label for="access ">Are they easily accessible?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="access" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="access" value="no"></td>
  </tr>
 <tr>
    <td>A7</td>
    <td><label for="access ">Are there enough fire extinguishers installed?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="install" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="install" value="no"></td>
  </tr>
   <tr>
    <td>A8</td>
    <td><label for="access ">Are all Extinguishers properly maintained?</label></td>
    <td> <label for="Auto">Yes</label>
                            <input type="checkbox" id="yes" name="maintain" value="yes">
                             <label for="Manual">No</label>
                            <input type="checkbox" id="no" name="maintain" value="no"></td>
  </tr>
</td>
</tr>
</table>
</br>
<table border=1>
  <tr>
    <th colspan="3">B: Fire Tanks & Pumps:</th>
   
  </tr>
  <tr>
   
    <td>B1</td>
    <td><label for="Auto"><b><u>Fire Water Tanks:</u></b></label></br></br>
    <label for="Auto">Capacity of Underground Tank</label></br></br>
  <label for="Auto">Capacity of Overhead Tank<label><br></td>
    <td> <label for="location"><b>Litres:</b></label>
  <input type="text" class="form-control"  id="litres " name="underground"  required>
                            <label for="location"><b>Litres:</b></label>
  <input type="text" class="form-control"  id="litres" name="overhead"  required></td>
  </tr>
 <tr>
    <td>B2</td>
   <td><label for="Auto"><b><u>Main Hydrant Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow" name="flow"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head" name="head" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power" name="power"  placeholder="HP" required>
</tr>
   <tr>
    <td>B3</td>
   <td><label for="Auto"><b><u>Hydrant Jockey Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode1" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode1" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run1" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run1" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow1" name="flow1"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head1" name="head1" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power1" name="power1"  placeholder="HP" required>
</tr>
<tr>
    <td>B4</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode2" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode2" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run2" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run2" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow2" name="flow2"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head2" name="head2" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power2" name="power2"  placeholder="HP" required>
</tr>
<tr>
    <td>B5</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode3" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode3" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run3" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run3" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow3" name="flow3"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head3" name="head3" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power3" name="power3"  placeholder="HP" required>
</tr>
<tr>
    <td>B6</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode4" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode4" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run4" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run4" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow4" name="flow4"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head4" name="head4" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power4" name="power4"  placeholder="HP" required>
</tr>
<tr>
    <td>B7</td>
   <td><label for="Auto"><b><u>Main Sprinkler Pump:</u></b></label></br></br>
    <label for="Auto">Mode of Operation</label>
             <label for="Manual">Auto</label>
                            <input type="checkbox" id="auto" name="mode5" value="auto">
                             <label for="Manual">Manual</label>
                             <input type="checkbox" id="manual" name="mode5" value="manual"><br>
                             <label for="Auto">Run Test Done?</label>
             <label for="Manual">Yes</label>
                            <input type="checkbox" id="yes" name="run5" value="yes">
                             <label for="Manual">No</label>
                             <input type="checkbox" id="no" name="run5" value="no"></td>
    <td><label for="Auto"><b><u>Make:</u></b></label></br></br>
   <label for="location"><b>Flow:</label>
  <input type="text" class="form-control"  id="flow5" name="flow5"  placeholder="m3/h" required>
 <label for="location"><b>Head:</b></label>
  <input type="text" class="form-control"  id="head5" name="head5" placeholder="m" required>
  <label for="location"><b>Power:</b></label>
  <input type="text" class="form-control"  id="power5" name="power5"  placeholder="HP" required>
</tr>
</td>
</tr>
</table>
</br>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remark"><b>Remarks/ Recommendations</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  required>  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" id="button" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>


  </form>
</div>
</div>
</div>
</div>






         <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
    <script>
  function select_location()
  {
   // alert("Enter in funt()");
  var data1=document.getElementById('client');
 // alert("data"+data1.value);
  var str =data1.value;
  var res =str.split("|");
 
 var Id= res[0];
 var first_name = res[1];
  var address = res[2];
  document.getElementById("location").value = address;

  //alert('ID'+Id);
 //alert(first_name);
  
  //alert('ID'+address);
  }


  var button = document.getElementById("button");
    var makepdf = document.getElementById("makepdf");
  
    button.addEventListener("click", function () {
        var mywindow = window.open("", "PRINT", 
                "height=400,width=600");
  
        mywindow.document.write(makepdf.innerHTML);
  
        mywindow.document.close();
        mywindow.focus();
  
        mywindow.print();
        mywindow.close();
  
        return true;
    });
</script>
  </body>
</html>