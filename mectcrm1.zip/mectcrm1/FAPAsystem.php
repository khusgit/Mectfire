     <?php include 'include/header.php';?>
      <!-- partial -->
        <!-- partial -->
        <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
             
                   <label for="reportnumber"><b>Report No</b></label>
             <?php 
                include('config.php');
                $sql = "SELECT Id from fapa";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
                    
            
          </div>

                <div class="card">
                <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
                  
            <div class="row">
              
                <div class="card">
                  <div class="card-body">
                    <form action="insertFAPA.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><U><b>FA & PA SYSTEM</b></U></h3>
                  
       <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Client Name</b></label>
    <div class="mb-3">


  
 
                          <?php
                           include("config.php");
						   $id=$_GET['ID'];
                           $sql = "SELECT * from client where id=$id";
                            $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
								 
                            ?>
                         <input type="text" class="form-control"  id="first_name" name="first_name" readonly value="<?php echo $row['first_name'];?>"required>  
		            
                 
                  </div>
      </div>
</div>
	<input type="text" class="form-control"  id="client_id" name="client_id" value=<?php echo $_GET['ID'];?> readonly hidden>  
               <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Location</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="location" name="location" readonly value="<?php echo $row['address'];?>"required>  
							
					</div>
			</div>
		</div>
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Society Name</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="Society_Name" name="Society_Name" value="<?php echo $row['Bulding_Name'];?>"readonly required>  
					</div>
			</div>
		</div>

  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Wings</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="wing" name="wing" value="<?php echo $wing=chr($_GET['wing'])." Wing";?>" readonly required>  	
				 <input type="text" class="form-control"  id="wings" name="wings" value="<?php echo $_GET['wing'];?>" readonly required hidden> 
   
                </div>
      </div>
</div> 
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Floor</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="floor" name="floor"value="<?php echo   $_GET['floor'] ;?>" readonly required>  	
   
                </div>
      </div>
</div>
							 <?php }?>
							  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
 
   <div ><b><u>FA & PA SYSTEM</u></b>
      <input type="radio" id="show" name="cylinder" value="yes" onChange="showhide();">
       <label for="html">Yes</label>
      <input type="radio" id="hide" name="cylinder" value="no" onChange="showhide();">
       <label for="css">No</label><br>
      </br>
    </div>
</div>
</div>
		<div  id="formfire" hidden>   
 

 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

            <div class="row">
               <label for="last_name"><b><U>Visual And Technical Check</U></b></label>
                               <div class="mb-6">
                            <label for="hooter"><b>Hooter: </b></label><br>
                              <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="hooter" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="hooter" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="hooter" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="hooter" value="missing">
 
  <div class="mb-5">
  

  </div>
</div>
</div> 
<div class="field half">
                            <label for="MCP"><b>MCP:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="MCP" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="MCP" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="MCP" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="MCP" value="missing">

  <div class="mb-5">

  </div>
</div>
</div> 
                         
                       <div class="field half">
                            <label for="Detector"><b>Detector:</b> </label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Detector" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Detector" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="Detector" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="Detector" value="missing">
                      
  <div class="mb-5">
    
  </div>
</div>
</div> 
                             <div class="field half">
                            <label for="Flow Switch"><b>Flow Switch: </b></label><br>
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="FlowSwitch" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="FlowSwitch" value="no">
                             <label for="D">D</label>
                             <input type="checkbox" id="d" name="FlowSwitch" value="d">
                              <label for="Missing"> Missing</label>
                             <input type="checkbox" id="missing" name="FlowSwitch" value="missing">
                        
  <div class="mb-5">
    
  </div>
</div>

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="address"><b>Address in Panel</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addressin"  >  
  </div>
</div>
</div> 

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="remarks"><b>Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  >  
  </div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="aremarks"><b> Additional Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addremark"  >  
  </div>
</div>
</div>
</div> 
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

   <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>

<!--<br/><br/>Download as 
<input type="button" name="export" value="&darr; Excel"/>&nbsp;&nbsp;<input type="button" name="export" value="&darr; PDF"/>-->

  </form>
</div>
</div>
</div>
</div>

 
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
 <script>
  function showhide()
{
//	var x=document.getElementById('id').checked;
	
	    if(document.getElementById('show').checked) 
		{   
           var selectedValue = document.getElementById('show').value;  
		   document.getElementById('formfire').hidden=false;
          // alert("Selected Radio Button is: " + selectedValue);    
        }
		if(document.getElementById('hide').checked) 
		{   
           var selectedValue = document.getElementById('hide').value;  
		    document.getElementById('formfire').hidden=true;
           //alert("Selected Radio Button is: " + selectedValue);    
		}  		
}
</script>
  </body>
</html>