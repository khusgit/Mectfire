     <?php include 'include/header.php';?>
	 <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
               <!-- <div class="nav-profile-image">
                  <img src="assets/images/faces/face1.jpg" alt="profile">
                  <span class="login-status online"></span>
                
                </div>-->
               <!-- <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">David Grey. H</span>
                  <span class="text-secondary text-small">Project Manager</span>
                </div>-->
              <!--  <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
              </a>
            </li>-->
           <li class="nav-item">
              <a class="nav-link" href="dashboard.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="service.php">
                <span class="menu-title">Service Engineers</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="client.php">
                <span class="menu-title">Client Form</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Inspection Report</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                 <li class="nav-item"> <a class="nav-link" href="fireextinguisherreport.php">Fire Extinguisher Report</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="firehandlereport.php"> Fire Handle System</a></li>
                   <li class="nav-item"> <a class="nav-link" href="firehosereport.php">Fire Hose Reel System</a></li>
                     <li class="nav-item"> <a class="nav-link" href="fapareport.php">FA & PA System</a></li>
                  <li class="nav-item"> <a class="nav-link" href="pumpreport.php">Pump System</a></li>
                 
                  <li class="nav-item"> <a class="nav-link" href="audit.php">Audit Form</a></li>

                </ul>
              </div>

            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Services Engineer </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><label for="date"><b> Date:</b></label></li>
                  <!--<label><?php echo date(d/m/y);?></label>-->
                  <!--<li class="breadcrumb-item active" aria-current="page">Add Vender</li>-->
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Services Engineer Form</h4>
                    <p class="card-description">  </p>
                    <form class="forms-sample">
                      <div class="form-group">
                        <label for="sname">Name</label>
                        <input type="text" class="form-control" name="sname" placeholder="Name">
                      </div>
                       <div class="form-group">
                        <label for="pname">Post Name</label>
                        <input type="text" class="form-control" name="pname" placeholder="Post Name">
                      </div>
                        <div class="form-group">
                        <label for="Gender">Gender</label>
                        <select class="form-control" name="Gender">
                          <option>Male</option>
                          <option>Female</option>
                        </select>
                      </div> 
                       <label for="pname">Date Of Birth</label>
                        <input type="date" class="form-control" name="dob" >
                      </div> 
                    

      
                       <div class="form-group">
                        <label for="mobile">Mobile No.</label>
                        <input type="text" class="form-control" name="mobile" >
                      </div>
                       <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="address" placeholder="Address">
                      </div>
                      <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" name="email" placeholder="Email">
                      </div>
                     <!-- <div class="form-group">
                        <label for="exampleInputPassword4">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                      </div>-->
                     
                    <!--  <div class="form-group">
                        <label>File upload</label>
                        <input type="file" name="img[]" class="file-upload-default">
                        <div class="input-group col-xs-12">
                          <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                          <span class="input-group-append">
                            <button class="file-upload-browse btn btn-gradient-primary" type="button">Upload</button>
                          </span>
                        </div>
                      </div>-->
                     <!-- <div class="form-group">
                        <label for="city">City</label>
                        <input type="text" class="form-control" name="city" placeholder="City">
                      </div>-->
                    <!--  <div class="form-group">
                        <label for="exampleTextarea1">Textarea</label>
                        <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
                      </div>-->
                      <a href="vendors.html" class="btn btn-gradient-primary me-2">Submit</a>
                      <!--<button class="btn btn-light">Submit</button>-->
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
           <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © Adc Technology.com 2022</span>
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end">  <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">Made by</a> @Adc Technology</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>