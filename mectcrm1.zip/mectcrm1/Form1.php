<?php include 'include/header.php';
$wings=chr(65);
 include("config.php");
 
$wing=$wings." Wing";
//echo "".$wing;
?>  
 
        <!-- partial -->
          <div class="main-panel">
         
            <div class="page-header">
              <!--<h3 class="page-title"> Add Vender </h3>-->
              <?php 
			  $flag=0;
			  $cid=0;
			  $floor=0;
			 
			  
			  if(isset($_GET['ID']) && isset($_GET['floor']) && isset($_GET['wing']))
			  {
				$flag=1;
				$cid=$_GET['ID'];
			  $floor=intval($_GET['floor'])-1;
			   if($_GET['floor']=='Parking')
			   {
				   
			   $wings=$_GET['wing']+1;   
				// echo "-------------------".($wings-65);
				$x=0;
				$sql = "SELECT * from client where id=$cid"; 
						    $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
								 
							 $x=$row['Wing'];
							 $floor=$row['Floor'];
							 }
							
					if(($wings-65)==intval($x))
					{
						
						// header('Location: fireextinguisherreport.php');
						echo"<script>window.location.href = 'fireextinguisherreport.php';</script>";
					}
			   }
			   else
			   {
				   $wings=$_GET['wing'];
				    
			   }
			  
			 $wing=chr($wings)." Wing";
			  }
			  ?>
            
             <div class="content-wrapper">
            <div class="page-header">
                          
                <div class="card">
                    <label for="location"><b>Report No- </b></label>
                <?php 
                include('config.php');
                $sql = "SELECT Id from mect1";
                $result=mysqli_query($conn,$sql);
                $id=0;
                 while($row = mysqli_fetch_assoc($result))
                  {
                       $id=$row["Id"];
                  }
                  $id++;
                  echo $id;

                ?> 
       
          </div>

                   <div class="card">
                <label for="date"><b> Date-</b>
                 <label><input readonly name="date"  value="<?php echo date('d/m/y');?>"></label>
               </label>
                </div>
              </div>
            <div class="row">
              
                <div class="card">
                  <div class="card-body">
                        <form action="insertmect.php" method="POST">
                    <h3 class="font-weight-bolder text-info text-gradient"><b><u>Fire Extinguisher Report</u></b></h3>
                  
       <div class="container-fluid py-4">
      <div class="row">
        
  
                          <?php
                           
						   if($flag==0)
						   {   
                           $sql = "SELECT * from client";
						   }
						   if($flag==1)
						   {
							   $sql = "SELECT * from client where id=$cid"; 
						   }
						   $result=mysqli_query($conn,$sql);
						   if($flag==0)
								 {
									 ?>
									 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Client Name</b></label>
    <div class="mb-3">

   <select id="client" name="first_name" class="form-control" onChange="select_location();">
    <option value="">----Select Client----</option>
									 <?php
                             while($row = mysqli_fetch_assoc($result))

                             {
								 
                            ?>
							
                                     <option value="<?php echo $row["id"]."|".$row["first_name"]."|".$row["address"]."|".$row["Bulding_Name"]."|".$row["Wing"]."|".$row["Floor"];?>">
                                        <?php echo $row['first_name'];?>
                                      
                                     </option> 
									       </div>
										   </div>
										   
							 </div><?php }?>
        <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Location</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="location" name="location" readonly required>  
							<input type="text" class="form-control"  id="client_id" name="client_id" readonly hidden>  
					</div>
			</div>
		</div>
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Society Name</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="Society_Name" name="Society_Name" readonly required>  
					</div>
			</div>
		</div>

  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Wings</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="wing" name="wing" value="<?php echo $wing;?>" readonly required>  	
   <input type="text" class="form-control"  id="wings" name="wings" value="<?php echo '65';?>" readonly required hidden>  	
                </div>
      </div>
</div> 
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Floor</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="floor" name="floor" readonly required>  	
   
                </div>
      </div>
</div>
                              <?php
                                     }
									 else
									 {
										 
                             while($row = mysqli_fetch_assoc($result))

                             {
								 
                            ?>
										               
       <div class="container-fluid py-4">
      <div class="row">
			<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="cname"><b>Client Name</b></label>
						<div class="mb-3">
						<input type="text" class="form-control"  id="first_name" name="first_name" readonly value="<?php echo $row['first_name'];?>"required>  
	    				  <input type="text" class="form-control"  id="client_id" name="client_id" value=<?php echo $_GET['ID'];?> readonly hidden>  
						 </div>
					 </div>
				 </div>
										 
					 <div class="row">					
               <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Location</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="location" name="location" readonly value="<?php echo $row['address'];?>"required>  
							
					</div>
			</div>
		</div>
		<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
				<label for="location"><b>Society Name</b></label>
					<div class="mb-3">
							<input type="text" class="form-control"  id="Society_Name" name="Society_Name" value="<?php echo $row['Bulding_Name'];?>"readonly required>  
					</div>
			</div>
		</div>

  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Wings</b></label>
				<div class="mb-3">

				<input type="text" class="form-control"  id="wing" name="wing" value="<?php echo $wing;?>" readonly required>  
<input type="text" class="form-control"  id="wings" name="wings" value="<?php echo $wings;?>" hidden required >  					
   
                </div>
      </div>
</div> 
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
     <div class="row">
        <label for="type"><b>Floor</b></label>
	
				<input type="text" class="form-control"  id="floor" name="floor"value="<?php 
	
	if($floor==0)
	echo "Ground";
	
	if($floor==-1)
		echo  "Parking";
	else
	echo $floor ;?>" readonly required>  	
   
                </div>
      </div>
</div>
	
									<?php  }
									 }
                                    ?>   
                    </select>
                  </div>
      </div>

<script>
  function select_location()
  {
   // alert("Enter in funtclient_id()");/ client_id
  var data1=document.getElementById('client');
 // alert("data"+data1.value);
  var str =data1.value;
  var res =str.split("|");
 
 var Id= res[0];
 var first_name = res[1];
  var address = res[2];
  var sname=res[3];
  var floor=res[5];
  var wing=res[4];
  document.getElementById("client_id").value = Id;
  document.getElementById("location").value = address;
   document.getElementById("Society_Name").value = sname;
   // document.getElementById("wing").value = wing;
    document.getElementById("floor").value = floor;
   
  //alert('ID'+Id);
 // alert('name'+first_name);
  
  //alert('ID'+address);
  }
</script>

      
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
 
   <div ><b><u>Fire Extinguisher</u></b>
      <input type="radio" id="show" name="cylinder" value="yes" onChange="showhide();">
       <label for="html">Yes</label>
      <input type="radio" id="hide" name="cylinder" value="no" onChange="showhide();">
       <label for="css">No</label><br>
      </br>
    </div>
</div>
</div>
            

			<div  id="formfire" hidden> 
			
       <div class="container-fluid py-4">
      <div class="row">
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
    <div class="row">
        <label for="last"><b> Refilling Date</b></label>
    <div class="mb-2">
  <input type="date" class="form-control" name="last"  shape="curve" >
</div>
</div>
</div>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
    <div class="row">
        <label for="next"><b>Due Refilling Date</b></label>
    <div class="mb-2">
  <input type="date" class="form-control" name="next"  shape="curve" >

</div>
</div>
</div>
<div class="field half">
  
  <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
    <div class="row">
 <label for="next"><b>Capacity</b></label>
  
   <select id="capacity" name="capacity" class="form-control" >
    
                        <option value="Type1">ABC 2Kg</option>
                        <option value="Type1">ABC 4Kg</option>
                        <option value="Type1">ABC 5Kg</option>  
                         <option value="Type1">ABC 6Kg</option>
                        <option value="Type1">ABC 9Kg</option>
                        <option value="Type1">ABC 10Kg</option> 
                         <option value="Type1">Co2 2Kg</option>
                        <option value="Type1">Co2 3Kg</option>
                       <option value="Type1">Co2 4.5Kg</option>
                       <option value="Type1">Co2 6Kg</option>
                       <option value="Type1">Co2 9Kg</option>
                       <option value="Type1">Water Form 4Kg</option>
                        <option value="Type1">Water Form 5Kg</option>
                         <option value="Type1">Water Form 9Kg</option>
                    </select>
                  </div>
      </div>
</div> 
   <div class="row">
 <div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
 <label for="PressureinGauge"><b> Pressure in Gauge:</b></label>
                            <div class="mb-6">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="PressureinGauge" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="PressureinGauge" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="PressureinGauge" value="na">
                            </div>
  <div class="mb-5">
  

  </div>
</div>
</div> 
</div>
 <div class="field half">
 <label for="HosePipe"><b> Hose Pipe:</b></label>
    <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="HosePipe" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="HosePipe" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="HosePipe" value="na">
                            </div>
  <div class="mb-5">
  

 
</div>
</div> 
<div class="field half">
 <label for="Nozzle"><b> Nozzle:</b></label>
    <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="Nozzle" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="Nozzle" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="Nozzle" value="na">
                            </div>
  <div class="mb-5">
  

</div>
</div> 
 <div class="field half">
 <label for="SafetyPin"><b> Safety Pin:</b></label>
    <div class="mb-5">
                            <label for="Ok">Ok</label>
                            <input type="checkbox" id="ok" name="SafetyPin" value="ok">
                             <label for="No"> No</label>
                            <input type="checkbox" id="no" name="SafetyPin" value="no">
                             <label for="NA"> NA</label>
                            <input type="checkbox" id="na" name="SafetyPin" value="na">
                        
  <div class="mb-5">
  
</div>
  
</div>
</div>

<div class="mb-3">
No = Not Ok | A = Available | NA = Not Available | D= Damaged

</div>

<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
        
  <label for="remark"><b>Remarks</b></label>
   <div class="row">
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="remark"  >  
  </div>
</div>
</div>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
  <label for="addremark"><b> Additional Remarks</b></label>
  <div class="mb-3">
  
  
   <input type="text" class="form-control"  name="addremark"  >  
  </div>
</div>
</div> 
 </div>
</div> </div>
<div class="col-xl-5 col-sm-7 mb-xl-2 mb-6">

    <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0">Submit</button>


  </form>



</div>

   
<!--<div id="show">Cylinder ( Yes / No )</div>
 <div class="menu" style="display: none;">-->
  </div>  
</div>
</div>
</div>
</div>


 
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
     <script>
	 /*
$(document).ready(function(){
    $('#show').click(function() {
      $('.menu').toggle("slide");

    });
    $('#hide').click(function(){
      $('.menu').toggle("slide");
    });
});*/
function showhide()
{
//	var x=document.getElementById('id').checked;
	
	    if(document.getElementById('show').checked) 
		{   
           var selectedValue = document.getElementById('show').value;  
		   document.getElementById('formfire').hidden=false;
          // alert("Selected Radio Button is: " + selectedValue);    
        }
		if(document.getElementById('hide').checked) 
		{   
           var selectedValue = document.getElementById('hide').value;  
		    document.getElementById('formfire').hidden=true;
          // alert("Selected Radio Button is: " + selectedValue);    
		}  		
}
</script>
  </body>
</html>