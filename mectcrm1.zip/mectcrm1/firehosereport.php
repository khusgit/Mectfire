     <?php include 'include/header.php';
	  include "config.php";
	  ?>
	 <!-- partial -->
  <div style= "width: 1200px; white-space: nowrap; overflow-x: scroll;">
          <div class="card-header pb-0">
          <h3 class="font-weight-bolder text-info text-gradient">Fire Hose Reel System Report</h3>
		  <div class="container-fluid ">
      <div class="row">
        <div class="col-xl-4 col-sm-7 mb-xl-2 mb-6">
          
			<form method="post" action="firehosereport.php">
        <label for="cname"><b>Client Name</b></label>
		<div class="mb-3">
		<select id="client" name="first_name" class="form-control">
		<option value="1"> Select Client Name</option>
                          <?php
                           include("config.php");
                           $sql = "SELECT * from client";
                            $result=mysqli_query($conn,$sql);
                             while($row = mysqli_fetch_assoc($result))

                             {
								 $first=$row['first_name'];
                            ?>
                                     <option value="<?php echo $row['first_name'];?>">
                                        <?php echo $row['first_name'];?>
                                      
                                     </option>
                                     <?php
                                     }
                                    ?>  
									</select>
			
			</div>
		</div>
			<div class="col-xl-4 col-sm-7 mb-xl-2 mb-6">
            <div class="row">
        <label for="cname"><b>Report Duration</b></label>
    <div class="mb-3">
	<select id="duration" name="duration" class="form-control">
									<option value="1"> Select Duration</option>
                                   <option value="1"> 1 Month</option>
								   <option value="3"> 3 Month</option>
								   <option value="6"> 6 Month</option>
								   <option value="12"> 1 Year</option>
                                        
                    </select>
					</div>
			</div>
		</div>
		<div class="col-xl-4 col-sm-7 mb-xl-2 mb-6">
<input type="submit" class="btn bg-gradient-info w-30 mt-0 mb-0 "   name="checkdata" value="search"/>
</div>
</form>
</div>
</div>            

            <div class="col-md-6 d-flex float-right">
				<?php 
			
			if(isset($_POST['checkdata']))
	
	 {
		 $name=$_POST['first_name'];
		 $date1=$_POST['duration'];
		 $date=date('Y-m-d');
		 if($date1=='1')
		 {
			 	 $future_timestamp = strtotime("-1 month");
		 }
		 if($date1=='3')
		 {
			 	 $future_timestamp = strtotime("-3 month");
		 }
		 if($date1=='6')
		 {
			 	 $future_timestamp = strtotime("-6 month");
		 }
		 if($date1=='12')
		 {
			 	 $future_timestamp = strtotime("-12 month");
		 }
		 
$data = date('Y-m-d', $future_timestamp);
	 }
	 if(isset($_POST['first_name']) && isset($_POST['duration']))
		{
		
			?>
		
			 <form method="POST" action="quotation3.php?client=<?php echo $name;?>&date=<?php echo $data;?>" target="blank">
			 
<input type="submit" class="btn bg-gradient-info w-30 mt-4 mb-0 "   name="export" value="&darr; PDF"/>

		</form><?php } ?>
               <a href="firehosereel.php"><button type="Form" class="btn bg-gradient-info w-30 mt-4 mb-0">FORM</button></a>
           </div>   
			</div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                       <th scope="col">Report No.</th>
                      <th scope="col">Client Name</th>
                      <th scope="col">Location</th>
                      <th scope="col">Building Address</th>
                      <th scope="col">Floor</th>
            <th scope="col">Ball_Value</th>
            <th scope="col">Connecting_Pipe</th>
            <th scope="col">Drum</th>
                      <th scope="col">Hose_Reel_Pipe</th>
         <th scope="col">Nozzle</th>
          <th scope="col">Jubil_Clamp</th>           
       <th scope="col">Remarks</th>
                   
           <th scope="col">Additional Remarks</th>
		   <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>

          <!--$sql = "SELECT * FROM firehose";-->
<?php
$result1=0;	 	
	if(isset($_POST['checkdata']))
	
	 {
		 $name=$_POST['first_name'];
		 $date1=$_POST['duration'];
		 $date=date('Y-m-d');
		 if($date1=='1')
		 {
			 	 $future_timestamp = strtotime("-1 month");
		 }
		 if($date1=='3')
		 {
			 	 $future_timestamp = strtotime("-3 month");
		 }
		 if($date1=='6')
		 {
			 	 $future_timestamp = strtotime("-6 month");
		 }
		 if($date1=='12')
		 {
			 	 $future_timestamp = strtotime("-12 month");
		 }
		 
		 
	 
	
$data = date('Y-m-d', $future_timestamp);
		// echo "Date start".$date;
		// echo "previous date".$data;
	//	 echo "name".$name;
		//echo "Enter in if";
		 //$sql = "SELECT * FROM mect1 where client='$name' AND date between '$date' and '$data' ORDER BY date DESC";
		 $sql="SELECT * FROM `firehose` WHERE `client`='$name' AND `date` BETWEEN '$data' AND '$date'; ";
          $result1=mysqli_query($conn,$sql);
     	
	 }
	 else
	 {
		 
       //$date=date('d/m/y');
          $sql = "SELECT * FROM firehose  ORDER BY date DESC";
          $result1=mysqli_query($conn,$sql);
     
	 }     
              while($row = mysqli_fetch_assoc($result1))
            {
        ?>
          <tr>
              <td><?php echo $row['id'];?>
                       <!-- <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['Client'];?>
                <!--        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['Location'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['baddress'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['floor'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['Ball_Value'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                              </div>
                        </div>-->
                      </td>
            <td><?php echo $row['Connecting_Pipe'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
             <td><?php echo $row['Drum'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
            <td><?php echo $row['Hose_Reel_Pipe'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
                       <td><?php echo $row['Nozzle'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
                      <td><?php echo $row['Jubil_Clamp'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
                       <td><?php echo $row['Remarks'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
                       <td><?php echo $row['additional_remark'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
						<td> <button type="button" class="btn btn-gradient-primary btn-fw">Edit</button><button type="button" class="btn btn-gradient-danger btn-fw">Delete</button> </td>
                      </tr>  
   
                         
            <?php }?>
              </table>
              </div>
            </div>
          </div>
        </div>
      </div>



 <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>