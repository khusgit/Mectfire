<?php
  
        include "config.php";
		echo"<br>user name----".$User_Name;
	   echo"<br>user pass----".$Password;
		
          $sql = "SELECT * from admin where userid=$User_Name && Password=$Password";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		  
        $User_Name = $_POST['exampleInputEmail1'];
        $Password = $_POST['exampleInputPassword1'];
          if(mysqli_num_rows($result) == 0)
		  {
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
					$name=$row['userid'];
					$pass=$row['password'];
					echo "<br>db name=".$name;
					echo "<br>db pass=".$pass;
					
					if($User_Name==$name && $Password==$pass)
					{
						  echo '<script>window.location.href = "dashboard.php";</script>';
					}
					else
					{
						 echo "<script type='text/javascript'>alert('Please enter correct valid id and password')</script>";
					echo '<script>window.location.href = "index.html";</script>';
						
					}
		
			  }
		    
		  }
		  
        
        
        ?>