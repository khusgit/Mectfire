     <?php include 'include/header.php';?>
	 <!-- partial -->
 <div style= "width: 1200px; white-space: nowrap; overflow-x: scroll;">
          <div class="card-header pb-0">
          <h3 class="font-weight-bolder text-info text-gradient"><b><u>Service Engineers Form Report</u></b></h3>
              <a href="service.php"><button type="Form" class="btn bg-gradient-info w-80 mt-8 mb-0">+Add Service Engineers</button></a>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th scope="col">Report No.</th>
                      <th scope="col">First Name</th>
                       <th scope="col">Last Name</th>
                        <th scope="col">Email ID</th>
                      <th scope="col">Gender</th>
                      <th scope="col">DOB</th>
            <th scope="col">Post</th>
             <th scope="col">Phone No.</th>
            <th scope="col">Address</th>
           
         <th scope="col">Date</th>
                   <th scope="col">Action</th>
      
                    </tr>
                  </thead>
                  <tbody>
   
        <?php
        include "config.php";
       $date=date('d/m/y');
          $sql = "SELECT * FROM service_engg";
          $result=mysqli_query($conn,$sql);
     
              while($row = mysqli_fetch_assoc($result))
            {
        ?>
          <tr>
             <td><?php echo $row['id'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['first_name'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['last_name'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['email'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['gender'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
          <td><?php echo $row['dob'];?>
                     <!--   <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                              </div>
                        </div>-->
                      </td>
            <td><?php echo $row['post'];?>
                <!--        <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
             <td><?php echo $row['contact'];?>
                     <!--   <div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
            <td>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"><?php echo $row['address'];?></h6>
                            
                          </div>
                        </div>-->
                      </td>
                       <td><?php echo $row['date'];?>
                        <!--<div class="d-flex px-2 py-1">
                          <div class="d-flex flex-column justify-content-center">
                            <h6 class="text-xs text-secondary mb-0"></h6>
                            
                          </div>
                        </div>-->
                      </td>
                      
                       
 <td> <button type="button" class="btn btn-gradient-primary btn-fw">Edit</button><button type="button" class="btn btn-gradient-danger btn-fw">Delete</button> </td>
                        
   
                         
            <?php }?>
                        
                      
            
            <!--</div>            
                      
             <td class="align-middle">
                        <a href="javascript:;" class="text-secondary font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user" onclick="openedit()">
                          Edit
                        </a>
                      </td>
          
          
          </tr>-->
        
<!--<div class="form-popup" id="myeditForm">
  <form action="" class="form-container" role="from" >
 <h3 class="font-weight-bolder text-info text-gradient">Update Customer</h3>

    <label for="customer"><b>Customer Name</b></label>
  <div class="mb-3">
    <input type="text" class="form-control" placeholder="Enter Customer Name" name="mname" required shape="curve">
  </div>
  
    
  <label for="mobile"><b>Mobile No.</b></label>
  <div class="mb-3">
    <input type="text" class="form-control" placeholder="Enter Mobile No." name="mobile" required>  
  </div>
  <label for="email"><b>Email Id</b></label>
    <input type="text" class="form-control" placeholder="Enter Email Id" name="email" required>

    <label for="category"><b>Category</b></label>
    <input type="text" class="form-control" placeholder="Enter Category" name="category" required>
  <label for="form"><b>Form</b></label>
  <input type="text" class="form-control" placeholder="Enter Form" name="form" required>
  <label for="feedback"><b>Feedback</b></label>
  <input type="text" class="form-control" placeholder="Enter Feedback" name="feedback" required>
  
  
  
  
  <script>
  function customeradd()
  {
  alert("Stock add");
  }
  </script>
  <button type="submit" class="btn bg-gradient-info w-100 mt-4 mb-0"onclick="customeradd()">Add</button>
  
  
    <button type="button" class="btn bg-gradient-info w-100 mt-4 mb-0" onclick="closeForm()">Close</button>
  </form>
</div>-->
                  
          
                </tr>
                </table>
              </div>
            </div>
          </div>
   </div>
 </div>



 <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="container-fluid d-flex justify-content-between">
             
              <span class="float-none float-sm-end mt-1 mt-sm-0 text-end"> Made by <a href="https://www.bootstrapdash.com/bootstrap-admin-template/" target="_blank">@Adc Technology</a> </span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/file-upload.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>